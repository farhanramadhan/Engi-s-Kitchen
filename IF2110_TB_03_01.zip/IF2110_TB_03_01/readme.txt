KELOMPOK YOUNGAWKARIN
NAMA / NIM :	FARHAN RAMADHAN / 13517001
		RAIHAN LUTHFI /  13517016
		GAMA PRADIPTA / 13517049
		AHMAD NAUFAL / 13517055
		SYAIFUL ANWAR / 13517139

CARA KOMPILASI PROGRAM : 
1. BUKA CMD
2. CD "../src"
3. gcc EngiKitchenExtended.c function.c ../ADT/array.c ../ADT/bintree.c ../ADT/jam.c ../ADT/matriks.c ../ADT/point.c ../ADT/stackt.c ../ADT/queue.c ../ADT/listrek.c initiation.c ../ADT/mesinkarmod.c ../ADT/mesinkatamod.c mapandmovement.c ../ADT/graph.c saveload.c help.c -o EngiKitchenExtended

