/* Graph berarah diimplementasi sebagai Multilist */

#include "graph.h"
#include "boolean.h"
#include <stdlib.h>
#include <stdio.h>

void CreateGraph (infotype_graph X , Graph * L){
/* I.S. Sembarang;  F.S. Terbentuk Graph dengan */
/* *** Manajemen Memory List Simpul (Leader); *** */
	adrNode P = AlokNodeGraph(X);
	if (P != Nil) FirstGraph(*L) = P;
}
adrNode AlokNodeGraph (infotype_graph X){
/* Mengembalikan address hasil alokasi Simpul X. */
	adrNode P = (adrNode) malloc (sizeof(NodeGraph));
	if (P!=Nil){
		InfoRoom(P) = X;
		NPred(P) = 0;
		NextGraph(P) = Nil;
		GraphTrail(P) = Nil;
	}
	return P;
}
void DealokNodeGraph (adrNode P){
/* I.S. P terdefinisi; F.S. P dikembalikan ke sistem */
/* *** Manajemen Memory List Successor (Trailer) *** */
	free(P);
}
adrSuccNode AlokSuccNode (adrNode Pn,infotype_trail coordinat){
/* Mengembalikan address hasil alokasi. */
/* Jika alokasi berhasil, maka address tidak Nil, misalnya menghasilkan Pt, maka Succ(Pt)=Pn dan Next(Pt)=Nil. Jika alokasi gagal, mengembalikan Nil. */
	adrSuccNode P = (adrSuccNode) malloc (sizeof(SuccNode));
	if (P!=Nil){
		Door(P) = coordinat;
		Succ(P) = Pn;
		NextTrail(P) = Nil;
	}
	return P;
}
void DealokSuccNode (adrSuccNode P){
/* I.S. P terdefinisi; F.S. P dikembalikan ke sistem */
	free(P);
}
/* *** Fungsi/Prosedur Lain *** */
adrNode SearchNodeGraph (Graph G, int X){
/* mengembalikan address simpul dengan Id=X jika sudah ada pada graph G, Nil jika belum */
	adrNode P = FirstGraph(G);
	while ((P != Nil) && (Id(InfoRoom(P)) != X)) P = NextGraph(P);
  return P;
}
adrSuccNode SearchEdge (Graph G, int Prec, int Succ){
	adrNode P = SearchNodeGraph(G,Prec);
	adrNode Q = SearchNodeGraph(G,Succ);
	adrSuccNode S = GraphTrail(P);
	while ((S != Nil) && (Succ(S) != Q)) S = NextTrail(S);
	return S;
}
void InsertNode (Graph * G, infotype_graph X, adrNode * P){
/* Menambahkan simpul X ke dalam graph, jika alokasi X berhasil. */
/* I.S. G terdefinisi, X terdefinisi dan belum ada pada G. */
/* F.S. Jika alokasi berhasil, X menjadi elemen terakhir G, Pn berisi address simpul X. Jika alokasi gagal, G tetap, Pn berisi Nil */
	adrNode R;
	*P = AlokNodeGraph(X);
	if (*P != Nil){
		if (FirstGraph(*G) == Nil) FirstGraph(*G) = *P;
		else {
			R = FirstGraph(*G);
			while (NextGraph(R) != Nil) R = NextGraph(R);
			NextGraph(R) = *P;
		}
	}
}
void InsertEdge (Graph * G, int prec, int succ, infotype_trail X){
	adrNode P = SearchNodeGraph(*G,prec);
	adrNode Q = SearchNodeGraph(*G,succ);
	adrSuccNode R, S;
	if ((P != Nil) && (Q != Nil)){
		R = AlokSuccNode(Q,X);
		if (R != Nil){
			if (GraphTrail(P)==Nil)
				GraphTrail(P)=R;
			else{
				NextTrail(GraphTrail(P))=R;
			}
		}
		else
			printf("kontol");
	}
}

adrNode SearchNextNode(Graph G, int prev, POINT X){
	boolean found = false;
	adrNode P = SearchNodeGraph(G,prev);
	adrSuccNode Q = GraphTrail(P);
	while ((Q!=Nil) && (!found)){
		if (Absis(X)==Absis(Door(Q)) && Ordinat(X)==Ordinat(Door(Q))){
			found = true;
			P = Succ(Q);
		}
		else
			Q = NextTrail(Q);
	}
	if (found)
		return P;
	else
		return Nil;
}

