/*Nama : Gama Pradipta Wirawan*/
/*Nim : 13517049*/
/*Nama File : array.c*/
#include "array.h"
#include <stdio.h>
#include <math.h>
#include "boolean.h"
#include "variable.h"
#include "bintree.h"
void MakeEmptyArray (TabInt * T)
/* I.S. T sembarang */
/* F.S. Terbentuk tabel T kosong dengan kapasitas IdxMax-IdxMin+1 */
{
    int i;
    Neff(*T)=0;
    for (i=IdxMin;i<=IdxMax;i++)
    {
        ElmtFood(Elmt(*T,i))=IdxUndef;
        ElmtTable(Elmt(*T,i))=IdxUndef;
    }
}

/* ********** SELEKTOR (TAMBAHAN) ********** */
/* *** Banyaknya elemen *** */
int NbElmtArray (TabInt T)
/* Mengirimkan banyaknya elemen efektif tabel */
/* Mengirimkan nol jika tabel kosong */
{
    return (Neff(T));
}
/* *** Daya tampung container *** */
int MaxNbEl (TabInt T)
{
    return (IdxMax-IdxMin+1);
}
/* Mengirimkan maksimum elemen yang dapat ditampung oleh tabel */
/* *** Selektor INDEKS *** */
IdxType GetFirstIdx (TabInt T)
/* Prekondisi : Tabel T tidak kosong */
/* Mengirimkan indeks elemen T pertama */
{
    return IdxMin;
}
IdxType GetLastIdx (TabInt T)
/* Prekondisi : Tabel T tidak kosong */
/* Mengirimkan indeks elemen T terakhir */
{
    return (Neff(T)+IdxMin-1);
}
/* ********** Test Indeks yang valid ********** */
boolean IsIdxValidArray (TabInt T, IdxType i)
/* Mengirimkan true jika i adalah indeks yang valid utk ukuran tabel */
/* yaitu antara indeks yang terdefinisi utk container*/
{
    return ((i>=IdxMin)&&(i<=IdxMax));
}
boolean IsIdxEffArray (TabInt T, IdxType i)
/* Mengirimkan true jika i adalah indeks yang terdefinisi utk tabel */
/* yaitu antara FirstIdx(T)..LastIdx(T) */
{
    return ((i>=GetFirstIdx(T))&&(i<=GetLastIdx(T)));
}

/* ********** TEST KOSONG/PENUH ********** */
/* *** Test tabel kosong *** */
boolean IsEmptyArray (TabInt T)
/* Mengirimkan true jika tabel T kosong, mengirimkan false jika tidak */
/* *** Test tabel penuh *** */
{
    return (Neff(T)==0);
}
boolean IsFullArray (TabInt T)
/* Mengirimkan true jika tabel T penuh, mengirimkan false jika tidak */
{
    return (Neff(T)==MaxNbEl(T));
}
/* ********** BACA dan TULIS dengan INPUT/OUTPUT device ********** */
/* *** Mendefinisikan isi tabel dari pembacaan *** */
void BacaIsi (TabInt * T)
/* I.S. T sembarang */
/* F.S. Tabel T terdefinisi */
/* Proses : membaca banyaknya elemen T dan mengisi nilainya */
/* 1. Baca banyaknya elemen diakhiri enter, misalnya N */
/*    Pembacaan diulangi sampai didapat N yang benar yaitu 0 <= N <= MaxNbEl(T) */
/*    Jika N tidak valid, tidak diberikan pesan kesalahan */
/* 2. Jika 0 < N <= MaxNbEl(T); Lakukan N kali: Baca elemen mulai dari indeks
      IdxMin satu per satu diakhiri enter */
/*    Jika N = 0; hanya terbentuk T kosong */
{
    IdxType n,i;
    do
    {
        scanf("%d",&n);
    }while ((n<0)||(n>MaxNbEl(*T)));
    MakeEmptyArray(T);
    if (n>0)
    {
        for (i=IdxMin;i<=n;i++)
        {
            scanf("%d",&ElmtFood(Elmt(*T,i)));
            scanf("%d",&ElmtTable(Elmt(*T,i)));
        }
        Neff(*T)=n;
    }
}
void TulisIsi (TabInt T)
/* Proses : Menuliskan isi tabel dengan traversal */
/* I.S. T boleh kosong */
/* F.S. Jika T tidak kosong : indeks dan elemen tabel ditulis berderet ke bawah */
/*      Jika T kosong : Hanya menulis "Tabel kosong" */
/* Contoh: Jika isi Tabel: [1, 20, 30, 50]
   Maka tercetak di layar:
   [1]1
   [2]20
   [3]30
   [4]50
*/
{
    int i;
    if (Neff(T)==0)
    {
        printf("\t\tOrderan kosong\n");
    }
    else
    {
        for (i=GetFirstIdx(T);i<=GetLastIdx(T);i++)
        {
            printf("\t\t[%d] %s\n",ElmtTable(Elmt(T,i)),Convert(ElmtFood(Elmt(T,i))));
        }
    }
}

boolean isElmtSama(ElType X, ElType Y){
	return (ElmtFood(X)==ElmtFood(Y) && ElmtTable(X)==ElmtTable(Y));
}
/* ********** SEARCHING ********** */
/* ***  Perhatian : Tabel boleh kosong!! *** */
IdxType SearchArray (TabInt T, ElType X)
/* Search apakah ada elemen tabel T yang bernilai X */
/* Jika ada, menghasilkan indeks i terkecil, dengan elemen ke-i = X */
/* Jika tidak ada, mengirimkan IdxUndef */
/* Menghasilkan indeks tak terdefinisi (IdxUndef) jika tabel T kosong */
/* Memakai skema search DENGAN boolean Found */
{
    IdxType i,indeks;
    boolean found;
    indeks = IdxUndef;
    found = false;
    if(!IsEmptyArray(T))
    {
        i = GetFirstIdx(T);
        while ((i<=GetLastIdx(T))&&(!found))
        {
            if(isElmtSama(Elmt(T,i),X))
            {
                found = true;
                indeks = i;
            }
            i++;
    }
    }
    return indeks;
}

/* ********** OPERASI LAIN ********** */
void CopyTab (TabInt Tin, TabInt * Tout)
/* I.S. Tin terdefinisi, Tout sembarang */
/* F.S. Tout berisi salinan dari Tin (elemen dan ukuran identik) */
/* Proses : Menyalin isi Tin ke Tout */
{
    *Tout = Tin;
}

/* ********** MENAMBAH ELEMEN ********** */
/* *** Menambahkan elemen terakhir *** Elmt(*T,Neff(*T)+1)=IdxUndef;*/
void AddAsLastEl (TabInt * T, ElType X)
/* Proses: Menambahkan X sebagai elemen terakhir tabel */
/* I.S. Tabel T boleh kosong, tetapi tidak penuh */
/* F.S. X adalah elemen terakhir T yang baru */
{
     Neff(*T)++;
     Elmt(*T,(GetLastIdx(*T)))=X;
}

void AddEli (TabInt * T, ElType X, IdxType i)
/* Menambahkan X sebagai elemen ke-i tabel tanpa mengganggu kontiguitas
   terhadap elemen yang sudah ada */
/* I.S. Tabel tidak kosong dan tidak penuh */
/*      i adalah indeks yang valid. */
/* F.S. X adalah elemen ke-i T yang baru */
/* Proses : Geser elemen ke-i+1 s.d. terakhir */
/*          Isi elemen ke-i dengan X */
{
    int j;
    for (j=GetLastIdx(*T);j>=i;j--)
    {
        Elmt(*T,j+1)=Elmt(*T,j);
    }
    Elmt(*T,i)=X;
    Neff(*T)++;
}

void DelEli (TabInt * T, IdxType i, ElType * X)
/* Menghapus elemen ke-i tabel tanpa mengganggu kontiguitas */
/* I.S. Tabel tidak kosong, i adalah indeks efektif yang valid */
/* F.S. X adalah nilai elemen ke-i T sebelum penghapusan */
/*      Banyaknya elemen tabel berkurang satu */
/*      Tabel T mungkin menjadi kosong */
/* Proses : Geser elemen ke-i+1 s.d. elemen terakhir */
/*          Kurangi elemen efektif tabel */
{
    IdxType j;
    *X = Elmt(*T,i);
    for (j=i;j<=GetLastIdx(*T);j++)
    {
        Elmt(*T,j)=Elmt(*T,j+1);
    }
    ElmtFood(Elmt(*T,(Neff(*T)+IdxMin-1)))=IdxUndef;
    ElmtTable(Elmt(*T,(Neff(*T)+IdxMin-1)))=IdxUndef;
    Neff(*T)--;
}
