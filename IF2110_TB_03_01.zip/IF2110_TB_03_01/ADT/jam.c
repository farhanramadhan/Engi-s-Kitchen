/* File: jam.c */
/*Nama : Gama Pradipta Wirawan */
/*NIM : 13517049 */


#include "jam.h"
#include "boolean.h"
#include "variable.h"
#include <stdio.h>

boolean IsJAMValid(int H, int M, int S)
{
    return ((H<=23)&&(H>=0)&&(M<=59)&&(M>=0)&&(S<=59)&&(S>=0));
}

JAM MakeJAM(int HH, int MM, int SS)
{
    JAM J;
    Hour(J)=HH;
    Minute(J)=MM;
    Second(J)=SS;
    return J;
}

void BacaJAM(JAM * J)
{
    int H,M,S;
    do
    {
        scanf("%2d %2d %2d",&H,&M,&S);
        if (IsJAMValid(H,M,S))
        {
            *J = MakeJAM(H,M,S);
            break;
        }
        else
        {
            printf("Jam tidak valid\n");
        }
    }while (IsJAMValid(H,M,S)==false);
}

void TulisJAM(JAM J)
{
    printf("%02d:%02d:%02d",Hour(J),Minute(J),Second(J));
}

long JAMToDetik (JAM J)
{
    return ((3600*Hour(J)+60*Minute(J)+Second(J)));
}

JAM DetikToJAM (long N)
{
    JAM J;
    N = N % 86400;
    Hour(J)= N / 3600;
    Minute(J)= (N % 3600) / 60;
    Second(J)= ((N % 3600) % 60);
    return J;
}

boolean JEQ(JAM J1, JAM J2)
{
    return ((Hour(J1)==Hour(J2))&&(Minute(J1)==Minute(J2))&&(Second(J1)==Second(J2)));
}

boolean JNEQ(JAM J1, JAM J2)
{
    return (!JEQ(J1,J2));
}
boolean JLT(JAM J1,JAM J2)
{
    return (JAMToDetik(J1)<JAMToDetik(J2));
}
boolean JGT(JAM J1, JAM J2)
{
    return (!JLT(J1,J2));
}
JAM NextDetik(JAM J)
{
    long dtk;
    dtk = JAMToDetik(J);
    dtk +=1;
    J = DetikToJAM(dtk);
    return J;
}
JAM NextNDetik(JAM J, int N)
{
    long dtk;
    dtk = JAMToDetik(J);
    dtk +=N;
    J = DetikToJAM(dtk);
    return J;
}
JAM PrevDetik(JAM J)
{
    long dtk;
    dtk = JAMToDetik(J);
    dtk -=1;
    J = DetikToJAM(dtk);
    return J;
}
JAM PrevNDetik(JAM J, int N)
{
    long dtk;
    dtk = JAMToDetik(J);
    dtk -=N;
    J = DetikToJAM(dtk);
    return J;
}
long Durasi(JAM JAw, JAM JAkh)
{
    long d1, d2;
    d1 = JAMToDetik(JAw);
    d2 = JAMToDetik(JAkh);
    if (d1>d2)
    {
        return (86400 -(d1-d2));
    }
    else
    {
        return (d2-d1);
    }
}
