#ifndef VARIABLE_H
#define VARIABLE_H

#include "boolean.h"
#define price 10000
#define Nil NULL
#define thingundef -999
//Jam,Point,Matriks,Kata,Array,Stack ada disini

/*-------------------------------------------------------------Definisi TYPE JAM <HH:MM:SS>---------------------------------------------------------- */
typedef struct {
	int HH; /* integer [0..23] */
	int MM; /* integer [0..59] */
	int SS; /* integer [0..59] */
} JAM;
/* *** Notasi Akses: selektor JAM *** */
#define Hour(J) (J).HH
#define Minute(J) (J).MM
#define Second(J) (J).SS

/* ----------------------------------------------------------- Definisi TYPE POINT --------------------------------------------------------------------- */
typedef struct {
	int X; /* absis   */
	int Y; /* ordinat */
}POINT;
/* *** Notasi Akses: Selektor POINT *** */
#define Absis(P) (P).X
#define Ordinat(P) (P).Y

/* ***---------------------------------------------------- Definisi TYPE Matrix -----------------------------------------------------------------*** */
#define BrsMin 1
#define BrsMax 100
#define KolMin 1
#define KolMax 100
typedef int indeks; /* indeks baris, kolom */
typedef char ElTypeMat;
typedef struct {
	ElTypeMat Mem[BrsMax+1][KolMax+1];
    int NBrsEff; /* banyaknya/ukuran baris yg terdefinisi */
	int NKolEff; /* banyaknya/ukuran kolom yg terdefinisi */
} MATRIKS;
/* *** Selektor *** */
#define NBrsEff(M) (M).NBrsEff
#define NKolEff(M) (M).NKolEff
#define ElmtMat(M,i,j) (M).Mem[(i)][(j)]

/* ***----------------------------------------------------------- Definisi TYPE Kata ------------------------------------------------------------*** */
#define NMax 10
#define BLANK ' '
#define STOP '|'
typedef struct {
	char TabKata[NMax+1]; /* container penyimpan kata, indeks yang dipakai [1..NMax] */
    int Length;
} Kata;

/* ***---------------------------------------------------------- Definisi TYPE Stack -------------------------------------------------------------*** */
#define MaxEl 10
typedef int infotype_stack;
typedef int stack_address;   /* indeks tabel */
typedef struct { 
	infotype_stack T[MaxEl+1]; /* tabel penyimpan elemen */
	stack_address TOP;  /* alamat TOP: elemen puncak */
} Stack;
/* *** Selektor *** */
#define Top(S) (S).TOP
#define InfoTop(S) (S).T[(S).TOP]

/* ***-------------------------------------------------------- Definisi TYPE ARRAYMOD -------------------------------------------------------------*** */
/*  Kamus Umum */
#define IdxMax 10
typedef int IdxType;  /* type indeks */
typedef struct{
	int Indeks_Makanan;
	int Nomer_Meja;
}ElType;   /* type elemen tabel */
typedef struct {
	ElType TI[IdxMax+1]; /* memori tempat penyimpan elemen (container) */
	int Neff; /* >=0, banyaknya elemen efektif */
} TabInt;
/* ********** SELEKTOR ********** */
#define Neff(T)   (T).Neff
#define TI(T)     (T).TI
#define Elmt(T,i) (T).TI[(i)]
#define ElmtFood(t)	(t).Indeks_Makanan
#define ElmtTable(t)	(t).Nomer_Meja

/* ------------------------------------------------------------------------Tipe Pesanan----------------------------------------------------------------*/
typedef struct{
	char Status; // ! : belum diambil pesanan, # : sudah diambil Pesanan, $ : sudah dimakan
	int Indeks_Makanan;
	int Nomer_Meja;
} Order;
#define Status(o) (o).Status
#define Food(o)	(o).Indeks_Makanan
#define Ntabel(o) (o).Nomer_Meja
/*---------------------------------------------------------------------------- Tipe Customer-------------------------------------------------------------*/
typedef struct{
	int patient;
	int prio;
	int people;
	POINT position;
	Order food;
}Customer;

#define Patient(C)	(C).patient
#define Prio(C)		(C).prio
#define People(C)	(C).people
#define CPosition(C) (C).position
#define CFood(C)	(C).food

/*------------------------------------------------------------------------Tipe Player---------------------------------------------------------------------*/
typedef struct{
	int life;
	long money;
	char name[20];
	JAM Time;
	POINT position;
	TabInt order;
	Stack Hand;
	Stack OnTray;
}Player;

#define Life(S)		(S).life
#define Money(S)	(S).money
#define Name(S)		(S).name
#define Position(S)	(S).position
#define ListOrder(S)	(S).order
#define OnHand(S)	(S).Hand
#define OnTray(S)	(S).OnTray
#define Time(S)		(S).Time

/*------------------------------------------------------------------------Tipe Table----------------------------------------------------------------------*/
typedef struct{
	POINT table_position;
	int capacity;
	boolean occupied;
	int number;
	Customer C_people;
}Table;
#define PosTable(T)	(T).table_position
#define Capacity(T)		(T).capacity
#define Occupied(T)		(T).occupied
#define InfoTable(T)	(T).C_people
#define NumberTab(T)	(T).number
/*--------------------------------------------------------------- Tipe Tray ----------------------------------------------------------------------------*/
typedef struct{
    POINT tray_position;
} Tray;
#define PosTray(T) (T).tray_position
/*--------------------------------------------------------------------Tipe Bahan ---------------------------------------------------------------------------*/
typedef struct{
    int Indeks_Bahan;
    POINT PosBahan;
} Ingredients;
#define IdxIng(I) (I).Indeks_Bahan
#define PosIng(I) (I).PosBahan

/*-----------------------------------------------------------------------Tipe Room--------------------------------------------------------------------------*/
typedef struct{
	MATRIKS M;
	int number;
	Table postab[100];
	Ingredients posing[100];
	Tray traypos;
}Room;

#define RoomNum(R) (R).number
#define RoomM(R) (R).M
#define RoomTab(R,i) (R).postab[i]
#define KitchenIng(R,i) (R).posing[i]
#define TrayPos(R) (R).traypos
/* ---------------------------------------------------------------------- Tipe Queue -------------------------------------------------------------------*/
typedef int address_queue;   /* indeks tabel */
/* Contoh deklarasi variabel bertype Queue : */
/* Versi I : tabel dinamik, Head dan Tail eksplisit, ukuran disimpan */
typedef Customer infotypeCust;
typedef struct { infotypeCust * T;   /* tabel penyimpan elemen */
                 address_queue HEAD;  /* alamat penghapusan */
                 address_queue TAIL;  /* alamat penambahan */
                 int MaxElQueue;     /* Max elemen queue */
               } Queue;
/* Definisi Queue kosong: HEAD=Nil; TAIL=Nil. */
/* Catatan implementasi: T[0] tidak pernah dipakai */

/* ********* AKSES (Selektor) ********* */
/* Jika Q adalah Queue, maka akses elemen : */
#define Head_Queue(Q) 		(Q).HEAD
#define Tail_Queue(Q) 		(Q).TAIL
#define InfoHead(Q)			(Q).T[(Q).HEAD]
#define InfoTail(Q)			(Q).T[(Q).TAIL]
#define Elmt_Queue(Q,i)		(Q).T[i]
#define MaxEl_Queue(Q) 		(Q).MaxElQueue

/* -------------------------------------------Definisi Type List--------------------------------------------------------------------*/
typedef int infotype;
typedef struct tElmtlist *address;
typedef struct tElmtlist { 
	infotype info;
	address next;
} ElmtList;

/* Definisi list : */
/* List kosong : L = Nil */
typedef address List;

/* Deklarasi  nama untuk variabel kerja */ 
/*  	L : List */
/*  	P : address 	*/
/* Maka penulisan First(L) menjadi L */
/*                P.info menjadi Info(P); P.next menjadi Next(P) */

/* Selektor */
#define Info(P) (P)->info
#define Next(P) (P)->next

/* *** ---------------------------------------------------------Definisi Type Pohon Biner------------------------------------------ *** */
/* typedef int infotype; */ /* type infotype sesuai pada modul listrek */
typedef struct tNode *addrNode;
typedef struct tNode
{
  infotype info;
  addrNode left;
  addrNode right;
} Node;

/* Definisi PohonBiner : */
/* Pohon Biner kosong : P = Nil */
typedef addrNode BinTree;

/* *** PROTOTYPE *** */

/* *** Selektor *** */
#define Akar(P) (P)->info
#define Left(P) (P)->left
#define Right(P) (P)->right

/* --------------------------------------------------------------------Definisi Type graph--------------------------------------------------------------- */
typedef struct{
	int Id;
	Room Room_graph;
}infotype_graph;

#define Id(P) (P).Id
#define RoomMap(P) (P).Room_graph

typedef struct tNodeGraph *adrNode; /* : pointer to Node */
typedef struct tSuccNode *adrSuccNode; /* : pointer to SuccNode */
typedef struct tNodeGraph { /* Node : < */
	infotype_graph infograph; /*  : integer, {identitas simpul} */
    int NPred; /* : integer,   {jumlah busur yang masuk ke simpul = jumlah simpul pred} */
    adrSuccNode Trail; /* : adrSuccNode, {pointer ke list trailer (simpul successor)} */
    adrNode NextGraph; /*  : adrNode > */
} NodeGraph;

#define InfoRoom(Pn) (Pn)->infograph
#define NPred(Pn) (Pn)->NPred
#define GraphTrail(Pn) (Pn)->Trail
#define NextGraph(Pn) (Pn)->NextGraph

typedef POINT infotype_trail;

typedef struct tSuccNode {
	infotype_trail infotrail;
    adrNode Succ; /* : adrNode,   {address simpul successor} */
    adrSuccNode NextTrail; /* : adrSuccNode > */
} SuccNode;

#define Door(Pt) (Pt)->infotrail
#define Succ(Pt) (Pt)->Succ
#define NextTrail(Pt) (Pt)->NextTrail

typedef struct { /* Graph : < */
    adrNode FirstGraph; /* : adrNode > */
    adrNode CurrentGraph; /* : adrNode > */
} Graph;
#define FirstGraph(G) (G).FirstGraph
#define CurrentGraph(G) (G).CurrentGraph
#endif
