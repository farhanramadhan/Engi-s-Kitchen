#include "mesinkatamod.h"
#include <stdio.h>

boolean EndKata;
Kata CKata;

void IgnoreBlank()
/* Mengabaikan satu atau beberapa BLANK
   I.S. : CC sembarang
   F.S. : CC ≠ BLANK atau CC = MARK */
   {
       while ((CC == BLANK)&&(CC != MARK))
       {
           ADVMOD();
       }
   }

void STARTKATA(int X)
/* I.S. : CC sembarang
   F.S. : EndKata = true, dan CC = MARK;
          atau EndKata = false, CKata adalah kata yang sudah diakuisisi,
          CC karakter pertama sesudah karakter terakhir kata */
{
    STARTMOD(X);
    IgnoreBlank();
    if (CC==MARK)
        EndKata = true;
    else if (CC!=MARK)
    {
        EndKata = false;
        SalinKata();
    }
}

void ADVKATA()
/* I.S. : CC adalah karakter pertama kata yang akan diakuisisi
   F.S. : CKata adalah kata terakhir yang sudah diakuisisi,
          CC adalah karakter pertama dari kata berikutnya, mungkin MARK
          Jika CC = MARK, EndKata = true.
   Proses : Akuisisi kata menggunakan procedure SalinKata */
{
    IgnoreBlank();
    if (CC==MARK)
        EndKata = true;
    else if (CC!= MARK)
    {
        SalinKata();
		IgnoreBlank();
    }
}
void SalinKata()
/* Mengakuisisi kata, menyimpan dalam CKata
   I.S. : CC adalah karakter pertama dari kata
   F.S. : CKata berisi kata yang sudah diakuisisi;
          CC = BLANK atau CC = MARK;
          CC adalah karakter sesudah karakter terakhir yang diakuisisi.
          Jika panjang kata melebihi NMax, maka sisa kata "dipotong" */
{
    int i;
    i = 0;
    while ((CC!=MARK)&&(CC!=BLANK)&&(i<NMax))
    {
        i++;
        CKata.TabKata[i]=CC;
        ADVMOD();
    }
    CKata.Length = i;
}

boolean StrCmp(const char * str1, const char * str2){
	while (*str1 == *str2){
		if (*str1 =='\0' || *str2 == '\0')
			break;
		str1++;
		str2++;
	}
	if (*str1 =='\0' && *str2 == '\0')
		return true;
	else
		return false;
}
