#include "queue.h"
#include "variable.h"
#include <stdio.h>
#include <stdlib.h>
boolean IsEmptyQueue (Queue Q){
/* Mengirim true jika Q kosong: lihat definisi di atas */
	return ((Head_Queue(Q)==Nill)&&(Tail_Queue(Q)==Nill));
}
boolean IsFullQueue (Queue Q){
/* Mengirim true jika tabel penampung elemen Q sudah penuh */
/* yaitu mengandung elemen sebanyak MaxEl */
	return (((Tail_Queue(Q)-Head_Queue(Q) + MaxEl_Queue(Q))%MaxEl_Queue(Q)+1)==MaxEl_Queue(Q));
}
int NBElmtQueue (Queue Q){
/* Mengirimkan banyaknya elemen queue. Mengirimkan 0 jika Q kosong. */
	if(IsEmptyQueue(Q))
		return 0;
	else
		return ((Tail_Queue(Q)-Head_Queue(Q) +MaxEl_Queue(Q))%MaxEl_Queue(Q)+1);
}
/* *** Kreator *** */
void CreateEmptyQueue (Queue * Q, int Max){
/* I.S. sembarang */
/* F.S. Sebuah Q kosong terbentuk dan salah satu kondisi sbb: */
/* Jika alokasi berhasil, Tabel memori dialokasi berukuran Max+1 */
/* atau : jika alokasi gagal, Q kosong dg MaxEl=0 */
/* Proses : Melakukan alokasi, membuat sebuah Q kosong */
	(*Q).T = (Customer *) malloc ((Max +1) * sizeof(Customer));
	if ((*Q).T == NULL ){
		MaxEl_Queue(*Q) = 0;
	}
	else{
		MaxEl_Queue(*Q)=Max;
		Head_Queue(*Q)=Nill;
		Tail_Queue(*Q)=Nill;
	}
}
/* *** Destruktor *** */
void DeAlokasiQueue(Queue * Q){
/* Proses: Mengembalikan memori Q */
/* I.S. Q pernah dialokasi */
/* F.S. Q menjadi tidak terdefinisi lagi, MaxEl(Q) diset 0 */
	MaxEl_Queue(*Q)=0;
	free((*Q).T);
}
/* *** Primitif Add/Delete *** */
void Add (Queue * Q, infotypeCust X){
/* Proses: Menambahkan X pada Q dengan aturan FIFO */
/* I.S. Q mungkin kosong, tabel penampung elemen Q TIDAK penuh */
/* F.S. X menjadi TAIL yang baru, TAIL "maju" dengan mekanisme circular buffer */
	int repeat=NBElmtQueue(*Q);
	int idx = Tail_Queue(*Q);
	if (IsEmptyQueue(*Q)){
		Tail_Queue(*Q)=1;
		Head_Queue(*Q)=1;
		InfoTail(*Q) = X;
	}
	else{
		while((Prio(X) > Prio((*Q).T[idx]) ) && (repeat > 0)){
			Elmt_Queue(*Q,((idx % MaxEl_Queue(*Q)) + 1)) = Elmt_Queue(*Q,idx);
			idx--;
			repeat--;
			if (idx==0){
				idx = MaxEl_Queue(*Q);
			}
		}
		Elmt_Queue(*Q,((idx % MaxEl_Queue(*Q)) + 1)) = X;
        Tail_Queue(*Q) = (Tail_Queue(*Q) % MaxEl_Queue(*Q)) + 1;
	}
}
void Del (Queue * Q, infotypeCust * X){
/* Proses: Menghapus X pada Q dengan aturan FIFO */
/* I.S. Q tidak mungkin kosong */
/* F.S. X = nilai elemen HEAD pd I.S., HEAD "maju" dengan mekanisme circular buffer; 
        Q mungkin kosong */
	if (NBElmtQueue(*Q)==1){
		
		*X=InfoHead(*Q);
		Head_Queue(*Q)=0;
		Tail_Queue(*Q)=0;
	}
	else{
		
		*X=InfoHead(*Q);
		Head_Queue(*Q)=(Head_Queue(*Q)%MaxEl_Queue(*Q))+1;
	}
}
void PrintQueue (Queue Q)
/* Mencetak isi queue Q ke layar */
/* I.S. Q terdefinisi, mungkin kosong */
/* F.S. Q tercetak ke layar dengan format:
<prio-1> <elemen-1>
...
<prio-n> <elemen-n>
#
*/
{
    infotypeCust Element;
    Queue temp;
    int i=1;
    /*
    while(i != ((Tail_Queue(Q) % MaxEl_Queue(Q)) + 1 ))
    {
        printf("%d %d\n", Prio((Q).T[i]) , Info((Q).T[i]));
        i = (i % MaxEl_Queue(Q)) + 1;
    }*/

    if (IsEmptyQueue(Q)){
        printf("\t\tAntrian Sedang Kosong !!\n");
    }
    else{
		temp = Q;
        while(!IsEmptyQueue(temp)){
            Del(&temp, &Element);
            printf("\t\tPelanggan Urutan Ke-%d : %d Orang | %d* Kesabaran | %d Prio\n", i, People(Element) , Patient(Element),Prio(Element));
            i++;
        }
    }
}

void Tick (Queue * Q,Player *P)
/* Mengurangi tingkat kesabaran pelanggan */
/* I.S. Q terdefinisi, mungkin kosong */
/* F.S. Prio(e) masing-masing pelanggan berkurang sebanyak 1 */
{
	/* Kamus Lokal */
	address_queue i;
	infotypeCust trash;
	/* Algoritma */
	if (!IsEmptyQueue(*Q))
	{
		i = Head_Queue(*Q);
		while (i!=Tail_Queue(*Q))
		{
			Patient(Elmt_Queue(*Q,i))--;
			if (Patient(Elmt_Queue(*Q,i))==0){
				Life(*P)--;
				DelInsideQueue(Q,i,&trash);
			}
			i = i % MaxEl_Queue(*Q) + 1;
		}
		Patient(Elmt_Queue(*Q,i))--;
			if (Patient(Elmt_Queue(*Q,i))==0){
				Life(*P)--;
				DelInsideQueue(Q,i,&trash);
			}
	}
}

void DelInsideQueue(Queue * Q, int i, infotypeCust * trash){
	int next;
	if (i == Head_Queue(*Q)){
		Del(Q,trash);
	}
	else{
		*trash = Elmt_Queue(*Q,i);
		while (i!=Tail_Queue(*Q)){
			next = (i) % (MaxEl_Queue(*Q))+1;
			Elmt_Queue(*Q,i) = Elmt_Queue(*Q,next);
			i=next;
		}
		Tail_Queue(*Q) = (Tail_Queue(*Q))%(MaxEl_Queue(*Q))-1;
		if(Tail_Queue(*Q)==0)
			Tail_Queue(*Q) = MaxEl_Queue(*Q);
	}
}
