/* File: mesinkar.c */
/* Implementasi Mesin Karakter */

#include "mesinkarmod.h"
#include <stdio.h>

char CC;
boolean EOP;

static FILE * pita;
static int retval;

void STARTMOD(int X) {
/* Mesin siap dioperasikan. Pita disiapkan untuk dibaca.
   Karakter pertama yang ada pada pita posisinya adalah pada jendela.
   I.S. : sembarang
   F.S. : CC adalah karakter pertama pada pita. Jika CC != MARK maka EOP akan padam (false).
          Jika CC = MARK maka EOP akan menyala (true) */

	/* Algoritma */
	switch (X) {
		case 4 : pita = fopen("../bin/kitchen.txt","r"); break;
		case 1 : pita = fopen("../bin/room1.txt","r"); break;
		case 2 : pita = fopen("../bin/room2.txt","r"); break;
		case 3 : pita = fopen("../bin/room3.txt","r"); break;
		default: break;
	}
	ADVMOD();
}

void ADVMOD() {
/* Pita dimajukan satu karakter.
   I.S. : Karakter pada jendela =
          CC, CC != MARK
   F.S. : CC adalah karakter berikutnya dari CC yang lama,
          CC mungkin = MARK.
		  Jika  CC = MARK maka EOP akan menyala (true) */

	/* Algoritma */
	retval = fscanf(pita,"%c",&CC);
	EOP = (CC == MARK);
	if (EOP) {
       fclose(pita);
 	}
}
