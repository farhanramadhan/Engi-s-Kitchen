/* File: point.c */
/*Nama : Gama Pradipta Wirawan */
/*NIM : 13517049 */

#include "point.h"
#include "boolean.h"
#include <stdio.h>
#include <math.h>
#include "variable.h"
POINT MakePOINT(int X, int Y)
{
    POINT P;
    Absis(P)=X;
    Ordinat(P)=Y;
    return P;
}

void BacaPOINT(POINT * P)
{
    int X,Y;
    scanf("%d %d", &X, &Y);
    *P = MakePOINT(X,Y);
}
void TulisPOINT(POINT P)
{
    printf("(%d,%d)",Absis(P),Ordinat(P));
}

boolean EQ(POINT P1, POINT P2)
{
    return ((Absis(P1)==Absis(P2))&&(Ordinat(P1)==Ordinat(P2)));
}
boolean NEQ(POINT P1, POINT P2 )
{
    return (!EQ(P1,P2));
}

boolean IsOrigin(POINT P )
{
    return ((Absis(P)==0)&&(Ordinat(P)==0));
}
boolean IsOnSbX(POINT P)
{
    return (Ordinat(P)==0);
}
boolean IsOnSbY(POINT P)
{
    return (Absis(P)==0);
}
int Kuadran(POINT P)
{
    if ((Absis(P)==0)||(Ordinat(P)==0))
    {
        return 0;
    }
    else if (Absis(P)>0)
    {
        if (Ordinat(P)>0)
        {
            return 1;
        }
        else if (Ordinat(P)<0)
        {
            return 4;
        }
    }
    else if (Absis(P)<0)
    {
        if (Ordinat(P)>0)
        {
            return 2;
        }
        else if (Ordinat(P)<0)
        {
            return 3;
        }
    }
}

POINT NextX(POINT P)
{
    Absis(P)=Absis(P)+1;
    return P;
}
POINT NextY(POINT P)
{
    Ordinat(P)=Ordinat(P)+1;
    return P;
}
POINT PrevX(POINT P)
{
    Absis(P)=Absis(P)-1;
    return P;
}
POINT PrevY(POINT P)
{
    Ordinat(P)=Ordinat(P)-1;
    return P;
}
POINT PlusDelta(POINT P,float deltaX, float deltaY )
{
    Absis(P)=Absis(P)+deltaX;
    Ordinat(P)=Ordinat(P)+deltaY;
    return P;
}
POINT MirrorOf(POINT P, boolean SbX)
{
    if (SbX)
    {
        Ordinat(P)=Ordinat(P)*(-1);
    }
    else
    {
        Absis(P)=Absis(P)*(-1);
    }
    return P;
}
float Jarak0(POINT P)
{
    return (sqrt((Absis(P)*(Absis(P))+(Ordinat(P)*Ordinat(P)))));
}
float Panjang(POINT P1,POINT P2)
{
    return(sqrt((Absis(P1)-Absis(P2))*(Absis(P1)-Absis(P2))+(Ordinat(P1)-Ordinat(P2))*(Ordinat(P1)-Ordinat(P2))));
}
void Geser(POINT *P, float deltaX, float deltaY)
{
    *P = PlusDelta(*P,deltaX,deltaY);
}
void GeserKeSbX(POINT * P)
{
    *P = MakePOINT(Absis(*P),0);
}
void GeserKeSbY(POINT * P)
{
    *P =  MakePOINT(0,Ordinat(*P));
}
void Mirror(POINT *P, boolean SbX)
{
    *P =  MirrorOf(*P,SbX);
}
void Putar(POINT *P, float Sudut)
{
    *P = MakePOINT((cos(Sudut)*Absis(*P)-sin(Sudut)*Ordinat(*P)),(sin(Sudut)*Absis(*P)+cos(Sudut)*Ordinat(*P)));
}
