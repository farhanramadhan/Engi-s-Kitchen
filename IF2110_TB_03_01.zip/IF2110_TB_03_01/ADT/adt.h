#ifndef _ADT_H
#define _ADT_H_
#include "jam.h"
#include "point.h"
#include "matriks.h"
#include "array.h"
#include "stackt.h"
#include "queue.h"
#include "bintree.h"
#include "boolean.h"
#include "mesinkarmod.h"
#include "mesinkatamod.h"
#include "graph.h"
#include "listrek.h"
#include "variable.h"
#endif
