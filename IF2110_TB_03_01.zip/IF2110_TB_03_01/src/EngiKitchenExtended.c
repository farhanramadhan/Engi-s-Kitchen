#include "../ADT/adt.h"
#include "mapandmovement.h"
#include "saveload.h"
#include "function.h"
#include "initiation.h"
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <time.h>
#include "help.h"

boolean IsGameOver(Player P);
boolean IsExit();
void PrintTitle();
void PrintPilihanMenu();
void PrintWelcome();
void PrintInvalidInput();
void PrintGameOver();
void EndGame();
void InitName(Player *P);

Player Human;
Graph Game;
BinTree recipe;
char command[100];
Queue CustQueue;
void GU(){
	Movement(&Human,&Game,"GU");
	ADDTIME(&Human,&Game,&CustQueue);
	RandomCust(&CustQueue);
}
void GD(){
	Movement(&Human,&Game,"GD");
	ADDTIME(&Human,&Game,&CustQueue);
	RandomCust(&CustQueue);
}
void GR(){
	Movement(&Human,&Game,"GR");
	ADDTIME(&Human,&Game,&CustQueue);
	RandomCust(&CustQueue);
}
void GL(){
	Movement(&Human,&Game,"GL");
	ADDTIME(&Human,&Game,&CustQueue);
	RandomCust(&CustQueue);
}
void ORDER(){
	TakeOrder(&Human,&RoomMap(InfoRoom(CurrentGraph(Game))));
	ADDTIME(&Human,&Game,&CustQueue);
	RandomCust(&CustQueue);
	//system("pause");
}
void PUT(){
	PutHandtoTray(&Human,recipe,TrayPos(RoomMap(InfoRoom(CurrentGraph(Game)))));
	ADDTIME(&Human,&Game,&CustQueue);
	RandomCust(&CustQueue);
	//system("pause");
}
void TAKE(){
	TakeIngredient(&Human,&RoomMap(InfoRoom(CurrentGraph(Game))));
	ADDTIME(&Human,&Game,&CustQueue);
	RandomCust(&CustQueue);
	//system("pause");
}
void CH(){
	ClearStack(&OnHand(Human));
	ADDTIME(&Human,&Game,&CustQueue);
	RandomCust(&CustQueue);
	//system("pause");
}
void CT(){
	ClearStack(&OnTray(Human));
	ADDTIME(&Human,&Game,&CustQueue);
	RandomCust(&CustQueue);
	//system("pause");
}
void PLACE(){
	PlaceCustomer(&Human,&CustQueue,&RoomMap(InfoRoom(CurrentGraph(Game))),Game);
	ADDTIME(&Human,&Game,&CustQueue);
	RandomCust(&CustQueue);
	//system("pause");
}
void GIVE(){
	GivetoCustomer(&Human,&RoomMap(InfoRoom(CurrentGraph(Game))));
	ADDTIME(&Human,&Game,&CustQueue);
	RandomCust(&CustQueue);
	//system("pause");
}
void RECIPE(){
	system("cls");
	PrintRecipe(recipe);
	system("pause");
}
void SAVE(){
	SaveFile(Game,Human,CustQueue);
}
void LOAD(){
	LoadFile(&Game,&Human,&CustQueue);
}
int main(){
	boolean exit = false;
	int menu;
	
	//title screen
	system("cls");
	PrintTitle();
	PrintWelcome();
	PrintPilihanMenu();
	printf("\t\t\t>> "); scanf("%d",&menu);
	while (menu!=3)
	{
		system("cls");
		if (menu<1 || menu>3)
		{
			PrintTitle();
			PrintInvalidInput();
			PrintPilihanMenu();
			printf("\t\t\t>> "); scanf("%d",&menu);
		}
		else if (menu==1||menu==2)
		{
			//preparing game
			PrintTitle();
			if (menu==1)
				InitName(&Human);
			InitNewGame(&Human);
			InitNewMap(&Game);
			Map_Graph(&Game,1,4);
			InitRecipe(&recipe);
			CreateEmptyQueue(&CustQueue,10);
			CurrentGraph(Game) = SearchNodeGraph(Game, 1);
			exit = false;
			if (menu==2)
				LOAD();
			//playing game
			do{
				Display_Map(&RoomMap(InfoRoom(CurrentGraph(Game))),Human,Id(InfoRoom(CurrentGraph(Game))));
				PrintQueue(CustQueue);printf("\t\t");
				PrintStack(OnHand(Human),"Hand");
				printf("\n");
				TulisIsi(ListOrder(Human));printf("\t\t");
				PrintStack(OnTray(Human),"Tray");
				printf("\n");
				printf("\t\tCommand : ");
				scanf("%s",command);
				if(StrCmp(command,"GU"))
					GU();
				else if (StrCmp(command,"GD"))
					GD();
				else if (StrCmp(command,"GR"))
					GR();
				else if (StrCmp(command,"GL"))
					GL();
				else if (StrCmp(command,"ORDER"))
					ORDER();
				else if (StrCmp(command,"PUT"))
					PUT();
				else if (StrCmp(command,"TAKE"))
					TAKE();
				else if (StrCmp(command,"CH"))
					CH();
				else if (StrCmp(command,"CT"))
					CT();
				else if (StrCmp(command,"PLACE"))
					PLACE();
				else if (StrCmp(command,"GIVE"))
					GIVE();
				else if (StrCmp(command,"RECIPE"))
					RECIPE();
				else if (StrCmp(command,"SAVE"))
					SAVE();
				else if (StrCmp(command,"HELP"))
					HELP();
				else if (StrCmp(command,"EXIT"))
				{
					if (IsExit())
						exit = true;
					else
						exit = false;
				}
				else{
					ADDTIME(&Human,&Game,&CustQueue);
					RandomCust(&CustQueue);
				}
			}while(!exit && !IsGameOver(Human));
			if (IsGameOver(Human))
				PrintGameOver(Human);	
		}
		PrintTitle();
		PrintWelcome();
		PrintPilihanMenu();
		printf("\t\t\t>> "); scanf("%d",&menu);
	}
	CREDITS();
	system("Pause");
	return 0;
}

/* nice things */
boolean IsGameOver(Player P)
{
	return (Life(P)<=0);
}

boolean IsExit()
{
	int menu = 0;
	printf("\n\t\tYakin keluar lu?\n");
	printf("\t\t1. Iya\n");
	printf("\t\t2. Tidak\n");
	printf("\t\t>> "); scanf("%d",&menu);
	while (menu!=1 && menu!=2)
	{
		PrintInvalidInput();
		printf("\t\t1. Iya\n");
		printf("\t\t2. Tidak\n");
		printf("\t\t>> "); scanf("%d",&menu);
	}
	if (menu==1)
		return true;
	else if (menu==2)
		return false;
	else
		return false;
}

void PrintTitle()
{
	system("cls");
	printf("\n:::::::::: ::::    :::  :::::::: ::::::::::: ::: ::::::::       :::    ::: ::::::::::: ::::::::::: ::::::::  :::    ::: :::::::::: ::::    ::: \n");
printf(":+:        :+:+:   :+: :+:    :+:    :+:     :+ :+:    :+:      :+:   :+:      :+:         :+:    :+:    :+: :+:    :+: :+:        :+:+:   :+: \n");
printf("+:+        :+:+:+  +:+ +:+           +:+        +:+             +:+  +:+       +:+         +:+    +:+        +:+    +:+ +:+        :+:+:+  +:+ \n");
printf("+#++:++#   +#+ +:+ +#+ :#:           +#+        +#++:++#++      +#++:++        +#+         +#+    +#+        +#++:++#++ +#++:++#   +#+ +:+ +#+ \n");
printf("+#+        +#+  +#+#+# +#+   +#+#    +#+               +#+      +#+  +#+       +#+         +#+    +#+        +#+    +#+ +#+        +#+  +#+#+#\n");
printf("#+#        #+#   #+#+# #+#    #+#    #+#        #+#    #+#      #+#   #+#      #+#         #+#    #+#    #+# #+#    #+# #+#        #+#   #+#+# \n");
printf("########## ###    ####  ######## ###########     ########       ###    ### ###########     ###     ########  ###    ### ########## ###    #### \n");
printf("\t:::    :::             ::::::::::: :::::::::: ::::    ::: :::::::::  :::::::::: :::::::::                                                      \n");
printf("\t:+:    :+:                 :+:     :+:        :+:+:   :+: :+:    :+: :+:        :+:    :+:                                                     \n");
printf("\t +:+  +:+                  +:+     +:+        :+:+:+  +:+ +:+    +:+ +:+        +:+    +:+                                                     \n");
printf("\t  +#++:+  +#++:++#++:++    +#+     +#++:++#   +#+ +:+ +#+ +#+    +:+ +#++:++#   +#+    +:+                                                     \n");
printf("\t +#+  +#+                  +#+     +#+        +#+  +#+#+# +#+    +#+ +#+        +#+    +#+                                                     \n");
printf("\t#+#    #+#                 #+#     #+#        #+#   #+#+# #+#    #+# #+#        #+#    #+#                                                     \n");
printf("\t###    ###                 ###     ########## ###    #### #########  ########## #########\n\n");
}

void PrintPilihanMenu()
{
	printf("\t\t\t1. New Game\n");
	printf("\t\t\t2. Load Game\n");
	printf("\t\t\t3. Exit Game\n");
}

void PrintWelcome()
{
	printf("\t\t\t*** Selamat datang di Engi's Kitchen Xpansion !!! ***\n\n");
}

void PrintInvalidInput()
{
	printf("\n\t\tInput salah !!!\n");
}

void PrintGameOver(Player P)
{
	Display_Map(&RoomMap(InfoRoom(CurrentGraph(Game))),Human,Id(InfoRoom(CurrentGraph(Game))));
	printf("\n\t\tKamu Kalah !!!\n\n");
	printf("\t\tSkor kamu = %ld\n\n",Money(P));
	printf("\t\t"); system("pause");
}

void InitName(Player *P)
{
	printf("\t\t\tMasukkan nama player\n");
	printf("\t\t\t>> "); scanf("%s",Name(*P));
	InitNewGame(P);
}
