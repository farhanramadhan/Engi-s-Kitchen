#include "adt.h"
#include "listrek.c"
#include "bintree.c"
#include "array.c"
#include "array.h"
#include "boolean.h"
#include <stdio.h>

/* Compile membutuhkan listrek.c, bintree.c dan array.c */

void PrintBoolean(boolean Bool);

int main() {
    /* KAMUS */
    TabInt T;
    ElType Meja1, Meja2;

    /* ALGORITMA */

    /* Membuat array kosong T */
    MakeEmptyArray(&T);

    /* Apakah array kosong ? */
    PrintBoolean(IsEmptyArray(T));

    /* Menambah isi array */
    ElmtFood(Meja1) = 20;
    ElmtTable(Meja1) = 1;
    ElmtFood(Meja2) = 21;
    ElmtTable(Meja2) = 2;
    AddAsLastEl(&T, Meja1);
    AddAsLastEl(&T, Meja2);

    /* Menuliskan isi array dan menconvert ke menu */
    TulisIsi(T);

    /* Menulis jumlah elemen array T */
    printf("\nJumlah elemen array : %d\n", NbElmtArray(T));
}

void PrintBoolean(boolean Bool) {
/* Prosedur untuk menampilkan boolean */
    if (Bool) {
        printf("True\n");
    } else {
        printf("False\n");
    }
}