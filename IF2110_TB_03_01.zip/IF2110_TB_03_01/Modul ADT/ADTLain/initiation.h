#ifndef _INITIATION_H
#define _INITIATION_H

#include "../ADT/adt.h"

void InitNewGame(Player * P);
/* 	I.S. Player sembarang.
	F.S. Player terinisiasi. */

void InitNewMap(Graph * G);
/* 	I.S Map kosong.
	F.S Map terinisiasi. */

void InitRecipe(BinTree * recipe);
/*	I.S. Resep kosong.
	F.S. Resep terinisiasi. */

void ADDTIME(Player *P, Graph * G, Queue *Q);
/*	I.S. Time sembarang.
	F.S. Time bertambah 1 tick. */

#endif
