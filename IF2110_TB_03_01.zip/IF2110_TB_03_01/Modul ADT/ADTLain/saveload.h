#ifndef _SAVELOAD_H
#define _SAVELOAD_H
#include "../ADT/adt.h"
#include <stdio.h>
#include <stdlib.h>
void STARTWRITE(int X);
/*	I.S. Save file sembarang/kosong.
	F.S. Save file berisi data-data dari permainan. */

void STARTREAD(int X);
/*	I.S. File .txt belum terbaca.
	F.S. File .txt terbaca. */

void PrintEksternalRoom (Room R);
/*	I.S. Room sembarang.
	F.S. Memasukkan data room ke dalam file eksternal. */
	void SaveFile(Graph G, Player P, Queue Q);
	void LoadFile(Graph * G, Player * P, Queue *Q);

void ReadEksternalRoom(Room * R);
/*	I.S. Room sembarang dari file eksternal.
	F.S. Membaca data room dari file eksternal dan memasukkannya ke program */

void PrintPlayer(Player P,int j);
/*	I.S. Player sembarang.
	F.S. Memasukkan data player ke dalam file eksternal. */

void ReadPlayer (Player * P,int *i);
/*	I.S. Player sembarang dari file eksternal.
	F.S. Data player dimasukkan kedalam program. */

void WriteQueue(Queue Q);
/*	I.S. Queue sembarang dari dalam program.
	F.S. Memasukkan data Queue ke dalam file eksternal. */

void ReadQueue(Queue * Q);
/*	I.S. Queue sembarang dari file eksternal.
	F.S. Memasukkan Queue dari file kesternal ke dalam program. */

void SaveFile(Graph G, Player P, Queue Q);
/*	I.S. Semua data dari program, sembarang.
	F.S. Memasukkan data dari program ke dalam file eksternal. */

void LoadFile(Graph * G, Player * P, Queue *Q);
/*	I.S. Semua data dari file eksternal, sembarang.
	F.S. Memasukkan data dari file eksternal ke dalam program. */
#endif
