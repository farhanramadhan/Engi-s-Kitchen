#include "../ADT/adt.h"
#include "initiation.h"
#include "mapandmovement.h"
#include "function.h"
#include <stdio.h>
#include <stdlib.h>

void InitNewGame(Player * P){
/* 	I.S. Player sembarang.
	F.S. Player terinisiasi. */
	Life(*P)=10;
	Money(*P)=100;
	Time(*P)=MakeJAM(10,00,00);
	Position(*P)=MakePOINT(5,4);
	MakeEmptyArray(&ListOrder(*P));
	CreateEmptyStack(&OnHand(*P));
	CreateEmptyStack(&OnTray(*P));
}
void InitNewMap(Graph * G){
/* 	I.S Map kosong.
	F.S Map terinisiasi. */
	FirstGraph(*G) = Nil;
	Map_Graph(G,1,4);
	CurrentGraph(*G)=FirstGraph(*G);
}

void InitRecipe(BinTree * recipe){
/*	I.S. Resep kosong.
	F.S. Resep terinisiasi. */
	int i;
	*recipe = BuildBalanceTree(16,1);
	for(i=9;i<=16;i++){
		AddDaun(recipe,i,(i+8),true);
	}
}

void ADDTIME(Player * P, Graph * G, Queue *Q){
/*	I.S. Time sembarang.
	F.S. Time bertambah 1 tick. */
	SitTic(G,P);
	Tick(Q,P);
	Time(*P) = DetikToJAM(JAMToDetik(Time(*P))+1);
}
