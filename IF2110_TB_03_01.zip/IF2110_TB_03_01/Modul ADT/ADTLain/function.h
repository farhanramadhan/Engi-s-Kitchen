#ifndef _FUNCTION_H
#define _FUNCTION_H
#include "../ADT/adt.h"
void EmptyTable(Table * T);
* I.S T Sembarang
   F.S Table T kosong */

boolean isNearTray(Player P, Tray T);
/* Mengirimkan true jika ada Tray di atas, bawah, atau samping Player P, 
   mengirimkan false jika tidak */

boolean isNearIng(Player P, Ingredients I);
/* Mengirmkan true jika ada Ingredients di atas, bawah, atau samping Player P,
   mengirimkan false jika tidak */

boolean isOccupiedTable (Table T);
/* Mengirimkan true jika Table T sudah terisi, mengirimkan false jika tidak */

int SearchIndeksCust (Queue Q);
/* Mengirimkan Indeks Customer terdepan pada Queue Q yang jumlah customernya < 3 */

void ChangeMap(MATRIKS * M, int n, Table * T, boolean occuppy);
/* I.S n dan T terdefinisi, occuppy terdefinisi
   F.S Element Matriks M yg berupa Chair berubah jadi Chair yg terisi atau tidak terisi sesuai occuppy */

boolean isfourtablefull(adrNode G);
/* Mengirimkan true jika semua table berkapasitas 4 orang di semua room sudah terisi,
   mengirimkan false jika tidak */
   
boolean isNearTable(Player P, Table T);
/* Mengirimkan true jika ada table pada 9 petak disekitar Player P dengan
   P sebagai pusat, megirimkan false jika tidak */

boolean isAbleGive(Player P, Table T);
/* Mengirimkan true jika makanan siap diberikan kepada Customer pada T,
   mengirimkan false jika tidak */

boolean isAblePlace(Player P, Customer C, Table T);
/* Mengirimkan true jika Customer C dapat ditempatkan pada Table T,
   mengirimkan false jika tidak */

boolean isAbleOrder(Player P, Table T);
/* Mengirimkan true jika dapat menerima pesanan dari table T,
   mengirimkan false jika tidak */

void SearchNearbyTable(Player *P, Room *R, Table *T, boolean *Nearby, int * IdxMeja);
/* I.S P, R, T, Nerby terdefinisi
   F.S P,R,T terdefinisi baru. IdxMeja terdefinisi sebagai index meja terdekat */

void SearchNearbyIng(Player *P, Room *R, Ingredients *T, boolean *Nearby);
/* I.S P, R, T, Nerby terdefinisi
   F.S P,R,T terdefinisi baru merepresentsikan Ingredients terdekat */

void deleteOrder(Player *P, ElType orderan);
/* I.S P, orderan terdefinisi
   F.S ListOrder(P) yg berelemen orderan di delete */

void inputOrder(Player *P, ElType orderan);
/* I.S P, orderan terdefinisi
   F.S menambahkan ListOrder(P) dengan elemen orderan */

void PutHandtoTray(Player *P, BinTree recipe, Tray T);
/* I.S P, recipe, dan T terdefinisi
   F.S menempatkan benda di tangan(hand) ke Tray, tidak ada benda di hand */

void ClearStack(Stack * S);
/* I.S S terdefinisi
   F.S S menjadi stack kosong */

void TakeIngredient(Player *P, Room * R);
/* I.S P, R terdefinisi
   F.S mengambil ingredient dari meja */

void PrintRecipe(BinTree recipe);
/* I.S recipe terdefinisi
   F.S Mencetak resep yang ada */

void GivetoCustomer(Player *P, Room * R);
/* I.S P, R terdefinisi
   F.S Memberikan makanan di tangan ke Customer di Table */

void TakeOrder(Player *P, Room * R);
/* I.S P, R terdefinisi
   F.S Menambahkan Order ke dalam array */

void PlaceCustomer(Player *P, Queue * Q, Room * R, Graph G);
/* I.S P, Q, R, G terdefinisi
   F.S Menempatkan Customer pada salah satu meja yang sesuai */

void RandomCust(Queue * Q);
/* I.S Q terdefnisi
   F.S Menambahkan Customer secara random ke dalam antrian customer */

void SitTic(Graph * G, Player * H);
/* I.S G, H terdefinisi
   F.S Mengurangi tick Customer yang sudah duduk */

#endif
