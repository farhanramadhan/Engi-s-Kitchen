
#include "help.h"
#include <stdio.h>
#include <time.h>
#include <stdlib.h>

void HELP()
{
	system("cls");
  printf("\t\tList Perintah yang tersedia :\n\n");
  printf("\t\t -- GU\t\tGo Up,  sehingga posisi player berpindah ke atas.\n");
  printf("\t\t -- GD\t\tGo Down,  sehingga posisi player berpindah ke bawah.\n");
  printf("\t\t -- GL\t\tGo Left,  sehingga posisi player berpindah ke kiri.\n");
  printf("\t\t -- GR\t\tGo Right,  sehingga posisi player berpindah ke kanan.\n");
  printf("\t\t -- ORDER\tCommand ini digunakan untuk mengambil order dari meja\n");
  printf("\t\t\t\tyang bersebelahan dengan pemain .\n");
  printf("\t\t -- PUT\t\tCommand ini digunakan untuk menaruh makanan di tangan(hand)\n");
  printf("\t\t\t\tke nampan .\n");
  printf("\t\t -- TAKE\tCommand ini digunakan untuk mengambil bahan yang bersebelahan\n");
  printf("\t\t\t\tdengan pemain.\n");
  printf("\t\t -- CH\t\tClear Hand,  Command ini digunakan untuk membuang seluruh\n");
  printf("\t\t\t\tbahan makanan yang terdapat di tangan pemain .\n");
  printf("\t\t -- CT\t\tClear Tray,  Command ini digunakan untuk membuang seluruh\n");
  printf("\t\t\t\tmakanan yang berada di dalam tray .\n");
  printf("\t\t -- PLACE\tCommand ini digunakan untuk menaruh pelanggan di meja dan\n");
  printf("\t\t\t\tkosong. Pelanggan yang ditaruh adalah pelanggan pada top of queue.\n");
  printf("\t\t -- GIVE\tMemberikan makanan yang berada di paling atas tumpukan\n");
  printf("\t\t\t\tke pengunjung yang bertetanggaan.\n");
  printf("\t\t -- RECIPE\tCommand ini digunakan untuk menampilkan pohon makanan. \n");
  printf("\t\t -- SAVE\tCommand ini digunakan untuk menyimpan state permainan\n");
  printf("\t\t\t\tsaat ini agar dapat dilanjutkan kemudian.\n");
  printf("\t\t -- EXIT\tCommand ini digunakan untuk keluar dari program. \n");
  printf("\t\t -- HELP\tCommand ini digunakan untuk menampilkan perintah yang tersedia. \n");
  system("pause");
}

void CREDITS()
{
  int i;
	for (i=1; i<=34;i++){
		system("@cls||clear");
		if (i<=20){
      for (int j = 1; j<=20-i; j++) printf("\n");
		}
		if (i>=1 && i<=20){
			printf("\t\t\t\t\t\t\t\t\t\tCredits to:\n\n");
		}
		if (i>=2 && i<=21){
			printf("\n");
		}
		if (i>=3 && i<=22){
			printf("\t\t\t\t\t\t\t\t     Farhan Ramadhan Syah Khair    13517001\n");
		}
		if (i>=4 && i<=23){
			printf("\n");
		}
		if (i>=5 && i<=24){
			printf("\t\t\t\t\t\t\t\t       Raihan Luthfi Haryawan    13517016\n");
		}
		if (i>=6 && i<=25){
			printf("\n");
		}
		if (i>=7 && i<=26){
			printf("\t\t\t\t\t\t\t\t        Gama Pradipta Wirawan   13517049\n");
		}
		if (i>=8 && i<=27){
			printf("\n");
		}
		if (i>=9 && i<=28){
			printf("\t\t\t\t\t\t\t\t         Ahmad Naufal Hakim    13517055\n");
		}
		if (i>=10 && i<=29){
			printf("\n");
		}
		if (i>=11 && i<=30){
			printf("\t\t\t\t\t\t\t\t           Syaiful Anwar     13517139\n\n");
		}
    if (i>=12 && i<=31){
			printf("\n\n");
		}
		if (i>=13 && i<=32){
      printf("\t\t\t   @@@ @@@   @@@@@@   @@@  @@@  @@@  @@@   @@@@@@@@   @@@@@@   @@@  @@@  @@@  @@@  @@@   @@@@@@   @@@@@@@   @@@  @@@  @@@\n");  
      printf("\t\t\t   @@@ @@@  @@@@@@@@  @@@  @@@  @@@@ @@@  @@@@@@@@@  @@@@@@@@  @@@  @@@  @@@  @@@  @@@  @@@@@@@@  @@@@@@@@  @@@  @@@@ @@@\n");  
      printf("\t\t\t   @@! !@@  @@!  @@@  @@!  @@@  @@!@!@@@  !@@        @@!  @@@  @@!  @@!  @@!  @@!  !@@  @@!  @@@  @@!  @@@  @@!  @@!@!@@@\n");  
      printf("\t\t\t   !@! @!!  !@!  @!@  !@!  @!@  !@!!@!@!  !@!        !@!  @!@  !@!  !@!  !@!  !@!  @!!  !@!  @!@  !@!  @!@  !@!  !@!!@!@!\n");  
      printf("\t\t\t    !@!@!   @!@  !@!  @!@  !@!  @!@ !!@!  !@! @!@!@  @!@!@!@!  @!!  !!@  @!@  @!@@!@!   @!@!@!@!  @!@!!@!   !!@  @!@ !!@!\n");  
      printf("\t\t\t     @!!!   !@!  !!!  !@!  !!!  !@!  !!!  !!! !!@!!  !!!@!!!!  !@!  !!!  !@!  !!@!!!    !!!@!!!!  !!@!@!    !!!  !@!  !!!\n");  
      printf("\t\t\t     !!:    !!:  !!!  !!:  !!!  !!:  !!!  :!!   !!:  !!:  !!!  !!:  !!:  !!:  !!: :!!   !!:  !!!  !!: :!!   !!:  !!:  !!!\n");  
      printf("\t\t\t     :!:    :!:  !:!  :!:  !:!  :!:  !:!  :!:   !::  :!:  !:!  :!:  :!:  :!:  :!:  !:!  :!:  !:!  :!:  !:!  :!:  :!:  !:!\n");  
      printf("\t\t\t      ::    ::::: ::  ::::: ::   ::   ::   ::: ::::  ::   :::   :::: :: :::    ::  :::  ::   :::  ::   :::   ::   ::   ::\n");  
      printf("\t\t\t      :      : :  :    : :  :   ::    :    :: :: :    :   : :    :: :  : :     :   :::   :   : :   :   : :   :    ::    :\n\n"); 

			printf("\t\t\t\t\t\t\t\t\t   **** * YoungAwKarin * ****\n");
		}
		float ms = 500;
	  clock_t start = clock();
	  while (clock()< (start+ms)); //delay(0.75);
	}
	
}

