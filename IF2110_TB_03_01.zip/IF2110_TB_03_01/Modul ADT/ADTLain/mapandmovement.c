#include "mapandmovement.h"
#include <stdio.h>
#include <stdlib.h>
#include "../ADT/adt.h"

boolean isOutMat(POINT X){
	/* Mengirimkan true jika keluar Matriks, mengirimkan false jika tidak */
	return (Absis(X)>8||Absis(X)<1||Ordinat(X)>8||Ordinat(X)<1);
}

boolean isAbleToWalk(POINT X,MATRIKS M){
	/* Mengirimkan true jika dapat berjalan/berpindah tempat, mengirimkan false jika tidak */
	return ElmtMat(M,Absis(X),Ordinat(X))==' ';
}

POINT Move_room(POINT X){
	/* Mengirimkan Point setelah mencapai pintu ruangan */
	if (Absis(X)==5 && Ordinat(X)==8)
		return MakePOINT(5,1);
	else if (Absis(X)==8 && Ordinat(X)==5)
		return MakePOINT(1,2);
	else if (Absis(X)==5 && Ordinat(X)==1)
		return MakePOINT(5,8);
	else if (Absis(X)==1 && Ordinat(X)==2)
		return MakePOINT(8,5);
	else
		return MakePOINT(-999,-999);
}

void Read_Grid(int X, MATRIKS * M){
	/* I.S X terdefinisi
   F.S M terdefinisi melalui pembacaan file eksternal */
	/*kamus & algoritma*/
	NBrsEff(*M) = 8; NKolEff(*M) = 8;
	MakeMATRIKS(NBrsEff(*M),NKolEff(*M),M);
	STARTMOD(X);
	int i = 1, j = 1;
	while (CC != '$'){
		ADVMOD();
	}
	ADVMOD();
	while (!EOP){	
		while ((CC == '\n') && (CC != MARK)) { // IgnoreBlank
			ADVMOD();
		}
		if (CC != ' '){
			if (CC == '#') CC = ' ';
			ElmtMat(*M,i,j) = CC;
			if (i <= 8) i++;
			if (i == 9){
				j++; i = 1; }
			}
		ADVMOD();
	}
}

void Data(Room * R, int i, int j, char idxmap, int k){
	/* I.S i, j, idxmap, k terdefinisi
   F.S R terdefinisi */
	Table M;
	Ingredients I;
	int temp;
	if (idxmap == 'M'){
		PosTable(M) = MakePOINT(i,j);
		NumberTab(M) = k;
		Occupied(M) = false;
		temp = k;
		if (k%2==1) Capacity(M) = 2;
		else Capacity(M) = 4;
		Patient(InfoTable(M)) = thingundef;
		Prio(InfoTable(M))= thingundef;
		People(InfoTable(M)) = thingundef;
		Food(CFood(InfoTable(M))) = thingundef;
		Ntabel(CFood(InfoTable(M))) = thingundef;
		CPosition(InfoTable(M)) = MakePOINT(thingundef,thingundef);
		Status(CFood(InfoTable(M))) = '$';
		RoomTab(*R,temp)=M;
	}
	else if (idxmap == 'I'){
		PosIng(I) = MakePOINT(i,j);
		IdxIng(I) = k;
		KitchenIng(*R,k) = I;
	}
	else{ //idxmap == T
		PosTray(TrayPos(*R))=MakePOINT(i,j);
	}
}

void Read_Table(Room * R){
	/* I.S sembarang
   F.S Table pada R terdefinisi */
	int i,j,count=1;
	MATRIKS M;
	M = RoomM(*R);
	for(i=1;i<=8;i++){
		for(j=1;j<=8;j++){
			if (ElmtMat(M,i,j)!=' ' && ElmtMat(M,i,j) !='X' && ElmtMat(M,i,j) != 'C' && ElmtMat(M,i,j) != 'P'){
				switch (ElmtMat(M,i,j)){
					case '1'	:	Data(R,i,j,'M',1);
									break;
					case '2'	:	Data(R,i,j,'M',2);
									break;
					case '3'	:	Data(R,i,j,'M',3);
									break;
					case '4'	:	Data(R,i,j,'M',4);
									break;
					case 'I'	:	Data(R,i,j,'I',count);
									count++;
									break;
					case 'T'	:	Data(R,i,j,'T',0);
									break;
					default		: break;	
				}
			}
			
		}
	}
}

void Read_Room(int X, Room * R){
	/* I.S X terdefinisi
   F.S R terdefinisi */
/* Proses : Read_Grid & Read_Table */
	Read_Grid(X, &RoomM(*R));
	Read_Table(R);
}

void Map_Graph(Graph * G,int x, int y){
	/* I.S x dan y terdefinisi
   F.S Graph G terdefinisi */
	int i;
	Room temp;
	infotype_graph graphtemp;
	adrNode P;
	infotype_trail pu,pd,pl,pr;
		/* pembentukan graph */
	FirstGraph(*G) = Nil;
	for (i=x;i<=y;i++){
		Read_Room(i,&temp);
		Id(graphtemp) = i%5;
		RoomMap(graphtemp) = temp;
		InsertNode(G,graphtemp,&P);
	}
	pu = MakePOINT(5,1);
	pd = MakePOINT(5,8);
	pr = MakePOINT(8,5);
	pl = MakePOINT(1,2);
	InsertEdge(G,1,2,pr);
	InsertEdge(G,1,4,pd);
	InsertEdge(G,2,1,pl);
	InsertEdge(G,2,3,pd);
	InsertEdge(G,3,2,pu);
	InsertEdge(G,3,4,pl);
	InsertEdge(G,4,1,pu);
	InsertEdge(G,4,3,pr);
}

void Movement(Player * P, Graph * G, char command[100]){
	/* I.S P, G, command terdefinisi
   F.S P dan G terdefinisi baru */
	boolean move=true;
	POINT prev,next;
	adrNode temp;
	MATRIKS M = RoomM(RoomMap(InfoRoom(CurrentGraph(*G))));
	int i = Id(InfoRoom(CurrentGraph(*G)));
	prev = Position(*P);
	if (StrCmp(command,"GD"))
		next = NextY(prev);
	else if (StrCmp(command,"GU"))
		next = PrevY(prev);
	else if (StrCmp(command,"GR"))
		next = NextX(prev);
	else if (StrCmp(command,"GL"))
		next = PrevX(prev);
	else move = false;
	if (move){
		if(!isOutMat(next)){
			if(isAbleToWalk(next,M)){
				Position(*P)=next;
			}
			else{// tidak bisa jalan
				printf("Ada Barang DiSana!!!\n");
			}
		}
		else{
			temp = SearchNextNode(*G,i,prev); //keluar map
			if (temp==Nil){
				printf("Nembus Tembok??\n");
				Position(*P)=prev;
			}
			else{
				CurrentGraph(*G)=temp;
				Position(*P)=Move_room(Position(*P));
			}
		}
	}
}

void Display_Map(Room * R, Player P, int Id){
	/* I.S R, P dan Id terdefinisi
   F.S Menampilkan R pada layar */
	int i,j;
	MATRIKS M=RoomM(*R);
	system("cls");// clearscrean
	printf("\n\t\t\t'''  Engi's Kitchen Xpansion  ''' \n\n");
	printf("\t\t$-----------------------------------------------$\n");
	printf("\t\t %s  \tMoney : %ld   Life : %d   Room : %d\n", Name(P), Money(P), Life(P), Id);
	printf("\t\t\t\t     ");TulisJAM(Time(P));printf("\n");
	printf("\t\t$-----------------------------------------------$\n");
	for (j=1; j<=8; j++){
		printf("\t\t");
		for (i=1; i<=8; i++){
			if (Absis(Position(P))==i && Ordinat(Position(P))==j)
				printf("|  P  ");
			else
				printf("|  %c  ",ElmtMat(M,i,j));
		}
		printf("|\n");
		if (j<8)
			printf("\t\t|-----|-----|-----|-----|-----|-----|-----|-----|\n");
	}
	printf("\t\t$-----------------------------------------------$\n");
}
