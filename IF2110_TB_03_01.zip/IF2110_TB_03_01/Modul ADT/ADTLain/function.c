#include "function.h"
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
void EmptyTable(Table * T){
/* I.S T Sembarang
   F.S Table T kosong */
	Occupied(*T) = false;
	Status(CFood(InfoTable(*T)))='!';
	Food(CFood(InfoTable(*T)))=thingundef;
	People(InfoTable(*T))=thingundef;
	Prio(InfoTable(*T)) = thingundef;
}

boolean isOccupiedTable (Table T){
/* Mengirimkan true jika Table T sudah terisi, mengirimkan false jika tidak */
	return Occupied(T);
}

int SearchIndeksCust (Queue Q){
/* Mengirimkan Indeks Customer terdepan pada Queue Q yang jumlah customernya < 3 */
	boolean found=false;
	int i;
	i = Head_Queue(Q);
	while (!found && i !=Tail_Queue(Q)){
		if (People(Elmt_Queue(Q,i))<3){
			found = true;
		}
		else{
			i = (i) % (MaxEl_Queue(Q))+1;
		}
	}
	if (People(Elmt_Queue(Q,i))<3){
			found = true;
	}
	if (found)
		return i;
	else
		return -999;
}

boolean isfourtablefull(adrNode G){
/* Mengirimkan true jika semua table berkapasitas 4 orang di semua room sudah terisi,
   mengirimkan false jika tidak */
	int i;
	int temp;
	boolean tes;
	if(Id(InfoRoom(G))==4)
		return true;
	else{
		i=1;
		tes = true;
		while (i<=2 && tes){
			temp = i*2;
			tes = isOccupiedTable(RoomTab(RoomMap(InfoRoom(G)),temp));
			i++;
		}
		if (tes)
			return isfourtablefull(NextGraph(G));
		else
			return false;
	}
}

boolean isNearTray(Player P, Tray T){
/* Mengirimkan true jika ada Tray di atas, bawah, atau samping Player P, 
   mengirimkan false jika tidak */
	int tempx, tempy;
	tempx = Absis(Position(P));
	tempy = Ordinat(Position(P));
	return (((tempx+1==Absis(PosTray(T))||tempx-1==Absis(PosTray(T))) && tempy == Ordinat(PosTray(T)))||((tempy+1==Ordinat(PosTray(T))
	||tempy-1==Ordinat(PosTray(T))) && Absis(Position(P)) == Absis(PosTray(T))));
}

boolean isNearIng(Player P, Ingredients I){
/* Mengirmkan true jika ada Ingredients di atas, bawah, atau samping Player P,
   mengirimkan false jika tidak */
	int tempx, tempy;
	tempx = Absis(Position(P));
	tempy = Ordinat(Position(P));
	return (((tempx+1==Absis(PosIng(I))||tempx-1==Absis(PosIng(I))) && tempy == Ordinat(PosIng(I)))||((tempy+1==Ordinat(PosIng(I))
	||tempy-1==Ordinat(PosIng(I))) && Absis(Position(P)) == Absis(PosIng(I))));
}

boolean isNearTable(Player P, Table T){
/* Mengirimkan true jika ada table pada 9 petak disekitar Player P dengan
   P sebagai pusat, megirimkan false jika tidak */
	int tempx, tempy;
	tempx = Absis(Position(P));
	tempy = Ordinat(Position(P));
	return ((tempy==Ordinat(PosTable(T)) || tempy-1 ==Ordinat(PosTable(T)) || tempy+1 == Ordinat(PosTable(T)))
	&&((tempx+1==Absis(PosTable(T)))||(tempx-1==Absis(PosTable(T)))||(tempx ==Absis(PosTable(T)))));
}

boolean isAbleGive(Player P, Table T){
/* Mengirimkan true jika makanan siap diberikan kepada Customer pada T,
   mengirimkan false jika tidak */
	if (!Occupied(T)){
	if (!Occupied(T)){
		printf("Meja Kosong!!!\n");
		return false;
	}
	else if (Status(CFood(InfoTable(T)))!='#'){
		printf("Customer belum dilayani!\n");
		return false;
	}
	else if(IsEmptyStack(OnTray(P))){
		printf("Tray kosong!!!\n");
		return false;
	}
	else if(InfoTop(OnTray(P))==Food(CFood(InfoTable(T))))
		return true;
	else{
		printf("Pesanan Tidak Sesuai");
		return false;
	}
}

boolean isAblePlace(Player P, Customer C, Table T){
/* Mengirimkan true jika Customer C dapat ditempatkan pada Table T,
   mengirimkan false jika tidak */
	if (Occupied(T)){
		printf("Meja sedang dipakai!!!\n");
		return false;
	}
	else if(People(C)>Capacity(T)){
		printf("Meja tidak cukup!!!\n");
		return false;
	}
	else
		return true;
}

boolean isAbleOrder(Player P, Table T){
/* Mengirimkan true jika dapat menerima pesanan dari table T,
   mengirimkan false jika tidak */
	if (!Occupied(T)){
		printf("Meja kosong!!!\n");
		return false;
	}
	else if (Status(CFood(InfoTable(T)))!='!'){
		printf("Customer Sudah dilayani!\n");
		return false;
	}
	else if (IsFullArray(ListOrder(P))){
		printf("Orderan Penuh!!!\n");
		return false;
	}
	else
		return true;
}

void ChangeMap(MATRIKS * M, int n, Table * T, boolean occuppy){
/* I.S n dan T terdefinisi, occuppy terdefinisi
   F.S Element Matriks M yg berupa Chair berubah jadi Chair yg terisi atau tidak terisi sesuai occuppy */
	int i, j,temp;
	char Chair;
	i = Absis(PosTable(*T));
	j = Ordinat(PosTable(*T));
	if (occuppy)
		Chair = 'C';
	else
		Chair = 'X';
	if (n>0){
		temp = i-1;
		ElmtMat(*M,(temp),j) = Chair;
		n--;
	}
	if (n>0){
		temp = i+1;
		ElmtMat(*M,(temp),j) = Chair;
		n--;
	}
	if (n>0){
		temp = j-1;
		ElmtMat(*M,i,temp) = Chair;
		n--;
	}
	if (n>0){
		temp = j+1;
		ElmtMat(*M,i,temp) = Chair;
		n--;
	}
}

void SearchNearbyTable(Player *P, Room *R, Table *T, boolean *Nearby, int * IdxMeja){
/* I.S P, R, T, Nerby terdefinisi
   F.S P,R,T terdefinisi baru. IdxMeja terdefinisi sebagai index meja terdekat */
	*Nearby = false;
	int i = 1;
	while (!(*Nearby) && i<=4){
		*Nearby = isNearTable(*P,RoomTab(*R,i));
		if(*Nearby){
			*T = RoomTab(*R,i);
			*IdxMeja = i;
		}
		else
			i++;
	}
}

void SearchNearbyIng(Player *P, Room *R, Ingredients *T, boolean *Nearby){
/* I.S P, R, T, Nerby terdefinisi
   F.S P,R,T terdefinisi baru merepresentsikan Ingredients terdekat */
 	*Nearby = false;
	int i = 1;
	while (!(*Nearby) && i<=16){
		*Nearby = isNearIng(*P,KitchenIng(*R,i));
		if (*Nearby)
			*T = KitchenIng(*R,i);
		else
			i++;
	}
}

void deleteOrder(Player *P, ElType orderan)
/* I.S P, orderan terdefinisi
   F.S ListOrder(P) yg berelemen orderan di delete */
{
	IdxType i;
	i = SearchArray(ListOrder(*P),orderan);
	DelEli(&ListOrder(*P),i,&orderan);
}

void inputOrder(Player *P, ElType orderan){
/* I.S P, orderan terdefinisi
   F.S menambahkan ListOrder(P) dengan elemen orderan */
	AddAsLastEl(&ListOrder(*P),orderan);
}

void PutHandtoTray(Player *P, BinTree recipe, Tray T){
	/* I.S P, recipe, dan T terdefinisi
   F.S menempatkan benda di tangan(hand) ke Tray, tidak ada benda di hand */
	Stack temp,check;
	int ing;
	boolean valid;
	BinTree food;
	if(isNearTray(*P,T)){
		CreateEmptyStack(&temp);
		CreateEmptyStack(&check);
		food = recipe;
		while(!IsEmptyStack(OnHand(*P))){
			Pop(&OnHand(*P),&ing);
			Push(&temp,ing);
			Push(&check,ing);
		}
		valid = true;
		while ((valid)&&(!IsEmptyStack(check))&&(!IsTreeEmpty(food))){
			if (InfoTop(check)==Akar(food)){
				Pop(&check,&ing);
				if (InfoTop(check)==Akar(Left(food))||IsEmptyStack(check))
					food = Left(food);
				else
					food = Right(food);
				}
			else{
				printf("%d",InfoTop(check));
				printf("%d",Akar(food));
				valid = false;
			}
		}
		if (!valid||IsFullStack(OnTray(*P))){
			printf("Gagal");
			while(!IsEmptyStack(temp)){
				Pop(&temp,&ing);
				Push(&OnHand(*P),ing);
			}	
		}
		else{
			if(!IsBiner(food)){
				Push(&OnTray(*P),Akar(food));
			}
			else
				printf("Bahan Kurang");
		}
	}
}

void ClearStack(Stack * S){
	/* I.S S terdefinisi
   F.S S menjadi stack kosong */
	CreateEmptyStack(S);
}

void TakeIngredient(Player *P, Room * R){
	/* I.S P, R terdefinisi
   F.S mengambil ingredient dari meja */
	Ingredients I;
	boolean Nearby;
	SearchNearbyIng(P,R,&I,&Nearby);
	if (Nearby && !IsFullStack(OnHand(*P))){
		Push(&OnHand(*P),IdxIng(I));
	}
	else
		printf("Tidak dapat mengambil bahan!!!");
}

void PrintRecipe(BinTree recipe){
	/* I.S recipe terdefinisi
   F.S Mencetak resep yang ada */
	int i;
	for(i=17; i<=24; i++){
		printf("[%d] %s\n",i,Convert(i));
		PrintIngridientRecipe(recipe,i);
		printf("\n");
	}
}

void GivetoCustomer(Player *P, Room * R){
	/* I.S P, R terdefinisi
   F.S Memberikan makanan di tangan ke Customer di Table */
	Table T;
	infotype_stack eat;
	int i;
	ElType d_order;
	boolean Nearby;
	SearchNearbyTable(P,R,&T,&Nearby,&i);
	if(Nearby){
		if(isAbleGive(*P,T)){
			Pop(&OnTray(*P),&eat);
			Money(*P) += People(InfoTable(T))*eat;
			ElmtFood(d_order) = eat;
			ElmtTable(d_order) = NumberTab(T);
			deleteOrder(P,d_order);
			EmptyTable(&RoomTab(*R,i));
			ChangeMap(&RoomM(*R),Capacity(RoomTab(*R,i)),&RoomTab(*R,i),Occupied(RoomTab(*R,i)));
		}
	}
	else{
		printf("Tidak dapat menyajikan makanan!!!");
	}
}

void TakeOrder(Player *P, Room * R){
	/* I.S P, R terdefinisi
   F.S Menambahkan Order ke dalam array */
	Table T;
	ElType a_order;
	int i;
	boolean Nearby;
	SearchNearbyTable(P,R,&T,&Nearby,&i);
	if(Nearby){
		if(isAbleOrder(*P,T)){
			ElmtFood(a_order) = Food(CFood(InfoTable(T)));
			ElmtTable(a_order) = NumberTab(T);
			inputOrder(P,a_order);
			Status(CFood(InfoTable(RoomTab(*R,i))))='#';
		}
	}
	else
		printf("Tidak dapat mengambil pesanan!!!");
}

void PlaceCustomer(Player *P, Queue * Q, Room * R, Graph G){
	/* I.S P, Q, R, G terdefinisi
   F.S Menempatkan Customer pada salah satu meja yang sesuai */
	Table T;
	infotypeCust X,Y;
	int i,j;
	boolean Nearby;
	SearchNearbyTable(P,R,&T,&Nearby,&i);
	if (Nearby){
		if(isAblePlace(*P,InfoHead(*Q),T)){
			Del(Q,&X);
			Patient(X) = 60 + rand() / (RAND_MAX/(30-15+1) + 1);
			//Patient(X) = 1000;
			CPosition(X) = PosTable(T);
			Ntabel(CFood(X))=NumberTab(T);
			Occupied(RoomTab(*R,i)) = true;
			InfoTable(RoomTab(*R,i)) = X;
			Status(CFood(InfoTable(RoomTab(*R,i))))='!';
			ChangeMap(&RoomM(*R),People(X),&RoomTab(*R,i),Occupied(RoomTab(*R,i)));
		}
		else{
			printf("Tes1");
			if((!isOccupiedTable(T))&&(People(InfoHead(*Q))>2)){
				printf("tes2");
				if(isfourtablefull(FirstGraph(G))){
					printf("tes3");
					j = SearchIndeksCust(*Q);
					if (j!=-999){
						printf("%d",j);
						printf("tes4");
						DelInsideQueue(Q,j,&Y);
						Patient(X) = 60 + rand() / (RAND_MAX/(30-15+1) + 1);
						//Patient(Y) = 1000;
						CPosition(Y) = PosTable(T);
						Ntabel(CFood(Y))=NumberTab(T);
						Occupied(RoomTab(*R,i)) = true;
						InfoTable(RoomTab(*R,i)) = Y;
						ChangeMap(&RoomM(*R),People(Y),&RoomTab(*R,i),Occupied(RoomTab(*R,i)));
					}
				}
				else{}
			}
		}
	}
	else
		printf("\t\tTidak dapat meletakan Customer!!!\n");
}

void RandomCust(Queue * Q){
	/* I.S Q terdefnisi
   F.S Menambahkan Customer secara random ke dalam antrian customer */

	int rand_cust;
	Customer C;
	rand_cust = rand()%19;
	if (rand_cust==1){
			if (!IsFullQueue(*Q)){
			Prio(C)=rand()%2;
			People(C)=rand()%4+1;
			Food(CFood(C))=rand()%8+17;
			Position(C)=MakePOINT(-999,-999);
			Status(CFood(C))='!';
			Ntabel(CFood(C))=-999;
			if (Prio(C)==0)
				Patient(C) = 50;
			else
				Patient(C) = 35;
			Add(Q,C);
		}
	}
}

void SitTic(Graph * G, Player * H){
/* I.S G, H terdefinisi
   F.S Mengurangi tick Customer yang sudah duduk */
	adrNode P;
	ElType d_order;
	int i;
	P = FirstGraph(*G);
	while (P!=Nil){
		for (i=1;i<=4;i++){
			if (Occupied(RoomTab(RoomMap(InfoRoom(P)),i))){
				Patient(InfoTable(RoomTab(RoomMap(InfoRoom(P)),i)))--;
				if (Patient(InfoTable(RoomTab(RoomMap(InfoRoom(P)),i)))==0){
					ElmtFood(d_order)=Food(CFood(InfoTable(RoomTab(RoomMap(InfoRoom(P)),i))));
					ElmtTable(d_order)=NumberTab((RoomTab(RoomMap(InfoRoom(P)),i)));
					deleteOrder(H,d_order);
					EmptyTable(&RoomTab(RoomMap(InfoRoom(P)),i));
					ChangeMap(&RoomM(RoomMap(InfoRoom(P))),Capacity(RoomTab(RoomMap(InfoRoom(P)),i)),&RoomTab(RoomMap(InfoRoom(P)),i),false);
					if (Life(*H)>0)
						Life(*H)--;
				}
			}
		}
		P = NextGraph(P);
	}
}
