#include "saveload.h"
#include "function.h"
#include "../ADT/adt.h"
#include <stdio.h>
#include <stdlib.h>

static FILE * savedata;
static FILE * readdata;
void STARTWRITE(int X){
/*	I.S. Save file sembarang/kosong.
	F.S. Save file berisi data-data dari permainan. */
	switch (X){
		case 1 : remove("../bin/dataroom1.txt");
				 savedata = fopen("../bin/dataroom1.txt","a"); break;
		case 2 : remove("../bin/dataroom2.txt");
				 savedata = fopen("../bin/dataroom2.txt","a"); break;
		case 3 : remove("../bin/dataroom3.txt");
				 savedata = fopen("../bin/dataroom3.txt","a"); break;
		case 4 : remove("../bin/dataplayer.txt");
				 savedata = fopen("../bin/dataplayer.txt","a"); break;
		case 5 : remove("../bin/datacustqueue.txt");
				 savedata = fopen("../bin/datacustqueue.txt","a"); break;
		default : break;
	}
}

void STARTREAD(int X){
/*	I.S. File .txt belum terbaca.
	F.S. File .txt terbaca. */
	switch (X){
		case 1 : readdata = fopen("../bin/dataroom1.txt","r"); break;
		case 2 : readdata = fopen("../bin/dataroom2.txt","r"); break;
		case 3 : readdata = fopen("../bin/dataroom3.txt","r"); break;
		case 4 : readdata = fopen("../bin/dataplayer.txt","r"); break;
		case 5 : readdata = fopen("../bin/datacustqueue.txt","r"); break;
		default : break;
	}
}

void PrintEksternalRoom (Room R){
/*	I.S. Room sembarang.
	F.S. Memasukkan data room ke dalam file eksternal. */
	int j;
	for (j=1;j<=4;j++){
		fprintf(savedata,"%d %d %d %c %d\n",(Occupied(RoomTab(R,j))),(People(InfoTable(RoomTab(R,j)))),(Food(CFood(InfoTable(RoomTab(R,j))))),Status(CFood(InfoTable(RoomTab(R,j)))),Patient(InfoTable(RoomTab(R,j))));
	}
}

void ReadEksternalRoom(Room * R){
/*	I.S. Room sembarang dari file eksternal.
	F.S. Membaca data room dari file eksternal dan memasukkannya ke program */
	int j,i;
	for (j=1;j<=4;j++){
		fscanf(readdata,"%d ",&i);
		if (i==1)
			Occupied(RoomTab(*R,j)) = true;
		else
			Occupied(RoomTab(*R,j)) = false;
		fscanf(readdata,"%d ",&People(InfoTable(RoomTab(*R,j))));
		fscanf(readdata,"%d ",&Food(CFood(InfoTable(RoomTab(*R,j)))));
		fscanf(readdata,"%c ",&Status(CFood(InfoTable(RoomTab(*R,j)))));
		fscanf(readdata,"%d",&Patient(InfoTable(RoomTab(*R,j))));
	}
}

void PrintPlayer(Player P,int j){
/*	I.S. Player sembarang.
	F.S. Memasukkan data player ke dalam file eksternal. */
	Stack temp;
	infotype_stack trash;
	TabInt T;
	int m=0, n,i;
	fprintf(savedata,"%d %d %ld %s %d %d %d %d %d ",j,Life(P),Money(P),Name(P),Absis(Position(P)),Ordinat(Position(P)),Hour(Time(P)),Minute(Time(P)),Second(Time(P)));
	temp = OnHand(P);
	while(!IsEmptyStack(temp)){
		fprintf(savedata,"%d ",InfoTop(temp));
		Pop(&temp,&trash);
	}
	fprintf(savedata,"%d ",m);
	temp = OnTray(P);
	while(!IsEmptyStack(temp)){
		fprintf(savedata,"%d ",InfoTop(temp));
		Pop(&temp,&trash);
	}
	fprintf(savedata,"%d ",m);
	n=NbElmtArray(ListOrder(P));
	T = ListOrder(P);
	i = 1;
	while (i<=n){
		fprintf(savedata,"%d %d ",ElmtFood(Elmt(T,i)),ElmtTable(Elmt(T,i)));
		i++;
	}
	fprintf(savedata,"%d ",m);
}

void ReadPlayer (Player * P,int *i){
/*	I.S. Player sembarang dari file eksternal.
	F.S. Data player dimasukkan kedalam program. */
	infotype_stack X;
	ElType Y;
	fscanf(readdata,"%d %d %ld %s %d %d %d %d %d ",i,&Life(*P),&Money(*P),Name(*P),&Absis(Position(*P)),&Ordinat(Position(*P)),&Hour(Time(*P)),&Minute(Time(*P)),&Second(Time(*P)));
	printf("tes1");
	fscanf(readdata,"%d ",&X);
	while(X != 0){
		Push(&OnHand(*P),X);
		fscanf(readdata,"%d ",&X);
		printf("%d ",X);
	}
	printf("tes1");
	fscanf(readdata,"%d ",&X);
	while(X != 0){
		Push(&OnTray(*P),X);
		fscanf(readdata,"%d ",&X);
	}
	printf("tes1");
	fscanf(readdata,"%d ",&X);
	while(X!=0){
		ElmtFood(Y)=X;
		fscanf(readdata,"%d ",&ElmtTable(Y));
		AddAsLastEl(&ListOrder(*P),Y);
		fscanf(readdata,"%d ",&X);
	}
	printf("tes1");
}

void WriteQueue(Queue Q){
/*	I.S. Queue sembarang dari dalam program.
	F.S. Memasukkan data Queue ke dalam file eksternal. */
	Queue temp;
	infotypeCust trash;
	int m = 100;
	temp = Q;
	while (!IsEmptyQueue(temp)){
		fprintf(savedata,"%d %d %d %d ",Patient(InfoHead(temp)),Prio(InfoHead(temp)),People(InfoHead(temp)),Food(CFood(InfoHead(temp))));
		Del(&temp,&trash);
	}
	fprintf(savedata,"%d ",m);
}

void ReadQueue(Queue * Q){
/*	I.S. Queue sembarang dari file eksternal.
	F.S. Memasukkan Queue dari file kesternal ke dalam program. */
	infotypeCust Y;
	int X;
	fscanf(readdata,"%d ",&X);
	while (X!=100){
		Patient(Y)=X;
		fscanf(readdata,"%d ",&Prio(Y));
		fscanf(readdata,"%d ",&People(Y));
		fscanf(readdata,"%d ",&Food(CFood(Y)));
		Add(Q,Y);
		fscanf(readdata,"%d ",&X);
		if (X == 100)
			break;
	}
}

void SaveFile(Graph G, Player P, Queue Q){
/*	I.S. Semua data dari program, sembarang.
	F.S. Memasukkan data dari program ke dalam file eksternal. */
	int i;
	adrNode Pn;
	Pn = FirstGraph(G);
	for (i=1;i<=5;i++){
		STARTWRITE(i);
		if (i<=3){
			PrintEksternalRoom(RoomMap(InfoRoom(Pn)));
			Pn = NextGraph(Pn);
		}
		else if(i==4){
			PrintPlayer(P,Id(InfoRoom(CurrentGraph(G))));
		}
		else{
			WriteQueue(Q);
		}
		fclose(savedata);
	}
}
void LoadFile(Graph * G, Player * P, Queue *Q){
/*	I.S. Semua data dari file eksternal, sembarang.
	F.S. Memasukkan data dari file eksternal ke dalam program. */
	int i,j,k;
	adrNode Pn;
	Stack temp;
	infotype_stack X;
	Pn = FirstGraph(*G);
	for (i=1;i<=5;i++){
		STARTREAD(i);
		if (i<=3){
			ReadEksternalRoom(&RoomMap(InfoRoom(Pn)));
			for (k=1;k<=4;k++){
				ChangeMap(&RoomM(RoomMap(InfoRoom(Pn))), People(InfoTable(RoomTab(RoomMap(InfoRoom(Pn)),k))),&RoomTab(RoomMap(InfoRoom(Pn)),k),Occupied(RoomTab(RoomMap(InfoRoom(Pn)),k)));
			}
			Pn = NextGraph(Pn);
		}
		else if(i==4){
			ReadPlayer(P,&j);
			CreateEmptyStack(&temp);
			temp = OnHand(*P);
			CreateEmptyStack(&OnHand(*P));
			while (!IsEmptyStack(temp)){
				Pop(&temp,&X);
				Push(&OnHand(*P),X);
			}
			temp = OnTray(*P);
			CreateEmptyStack(&OnTray(*P));
			while(!IsEmptyStack(temp)){
				Pop(&temp,&X);
				Push(&OnTray(*P),X);
			}
		}
		else{
			ReadQueue(Q);
		}
		fclose(readdata);
	}
	CurrentGraph(*G)=SearchNodeGraph(*G,j);
}
