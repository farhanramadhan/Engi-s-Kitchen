#ifndef _MAPANDMOVEMENT_H
#define _MAPANDMOVEMENT_H
#include "../ADT/adt.h"

boolean isOutMat(POINT X);
/* Mengirimkan true jika keluar Matriks, mengirimkan false jika tidak */

boolean isAbleToWalk(POINT X,MATRIKS M);
/* Mengirimkan true jika dapat berjalan/berpindah tempat, mengirimkan false jika tidak */

POINT Move_room(POINT X);
/* Mengirimkan Point setelah mencapai pintu ruangan */

void Read_Grid(int X, MATRIKS * M);
/* I.S X terdefinisi
   F.S M terdefinisi melalui pembacaan file eksternal */

void Data(Room * R, int i, int j, char idxmap, int k);
/* I.S i, j, idxmap, k terdefinisi
   F.S R terdefinisi */

void Read_Table(Room * R);
/* I.S sembarang
   F.S Table pada R terdefinisi */

void Read_Room(int X, Room * R);
/* I.S X terdefinisi
   F.S R terdefinisi */
/* Proses : Read_Grid & Read_Table */

void Map_Graph(Graph * G,int x, int y);
/* I.S x dan y terdefinisi
   F.S Graph G terdefinisi */
   
void Movement(Player * P, Graph * G, char command[100]);
/* I.S P, G, command terdefinisi
   F.S P dan G terdefinisi baru */
   
void Display_Map(Room * R, Player P, int Id);
/* I.S R, P dan Id terdefinisi
   F.S Menampilkan R pada layar */

#endif
