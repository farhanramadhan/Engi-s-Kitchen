/* Nama file : driver_jam.c
   Tanggal : 26 November 2018
   NIM/Nama : 13517055/Ahmad Naufal Hakim */

#include <stdio.h>
#include "boolean.h"
#include "bintree.h"
#include "listrek.h"


int main()
{
	/*** Kamus ***/
	BinTree T,TL,TR,BBT,AN;
	infotype t,tl,tr,an,X;

	/*** Algoritma ***/
	//Tree && MakeTree && PrintTree
	printf("testing fungsi dan/atau prosedur Tree, MakeTree, PrintTree\n");
	printf("Masukkan nilai t: "); scanf("%d",&t);
	printf("Masukkan nilai tl: "); scanf("%d",&tl);
	printf("Masukkan nilai tr: "); scanf("%d",&tr);
	MakeTree(tl,Nil,Nil,&TL);
	MakeTree(tr,Nil,Nil,&TR);
	T = Tree(t,TL,TR);
	printf("Pohon T:\n");
	PrintTree(T,2); printf("\n");

	//BuildBalanceTree
	printf("testing fungsi dan/atau prosedur BuildBalanceTree(int n, int i) dengan n=24 dan i=1\n");
	BBT = BuildBalanceTree(24,1);
	printf("Pohon BBT:\n");
	PrintTree(BBT,2); printf("\n");

	//AlokNode && DealokNode && IsTreeOneElmt && IsTreeEmpty
	printf("testing fungsi dan/atau prosedur AlokNode, DealokNode, IsTreeOneElmt, IsTreeEmpty\n");
	printf("Masukkan nilai an: "); scanf("%d",&an);
	printf("Pohon AN:\n");
	AN = AlokNode(an);
	PrintTree(AN,2);
	printf("Pohon AN mempunyai 1 elemen adalah "); if (IsTreeOneElmt(AN)) printf("benar\n"); else printf("salah\n");
	printf("Pohon AN kosong adalah "); if (IsTreeEmpty(AN)) printf("benar\n\n"); else printf("salah\n");
	printf("Pohon AN didealokasi\n\n"); DealokNode(AN);

	//AddDaunTerkiri && IsUnerLeft && IsUnerRight && IsBiner
	printf("testing fungsi dan/atau prosedur AddDaunTerkiri, IsUnerLeft, IsUnerRight, IsBiner\n");
	printf("AddDaunTerkiri(&T,100)\n");
	AddDaunTerkiri(&T,100);
	printf("Pohon T:\n");
	PrintTree(T,2);
	printf("IsUnerLeft(Left(T)) adalah "); if (IsUnerLeft(Left(T))) printf("benar\n"); else printf("salah\n");
	printf("IsUnerRight(T) adalah "); if (IsUnerRight(T)) printf("benar\n"); else printf("salah\n");
	printf("IsBiner(T) adalah "); if (IsBiner(T)) printf("benar\n\n"); else printf("salah\n\n");

	//PrintPreorder && PrintInorder && PrintPostorder
	printf("testing fungsi dan/atau prosedur PrintPreorder, PrintInorder, PrintPostorder\n");
	printf("Pohon T:\n"); PrintPreorder(T); printf("\n");
	printf("Pohon T:\n"); PrintInorder(T); printf("\n");
	printf("Pohon T:\n"); PrintPostorder(T); printf("\n\n");

	//DelDaun && IsSkewLeft && IsSkewRight
	printf("testing fungsi dan/atau prosedur DelDaun, IsSkewLeft, IsSkewRight\n");
	printf("DelDaun(Right(T),X) dengan X=tr\n");
	X=tr; DelDaun(&Right(T),X);
	printf("Pohon T:\n");
	PrintTree(T,2);
	printf("IsSkewLeft(T) adalah "); if (IsSkewLeft(T)) printf("benar\n"); else printf("salah\n");
	printf("IsSkewRight(T) adalah "); if (IsSkewRight(T)) printf("benar\n\n"); else printf("salah\n\n");

	//Level && NbElmt && NbDaun
	printf("testing fungsi dan/atau prosedur Level, NbElmt, NbDaun\n");
	printf("Tinggi pohon BBT: "); printf("%d\n",Tinggi(BBT));
	printf("Banyak elemen pohon BBT: "); printf("%d\n",NbElmt(BBT));
	printf("Banyak daun pohon BBT: "); printf("%d\n\n",NbDaun(BBT));

	//PrintIngredientRecipe && Convert
	printf("testing fungsi dan/atau prosedur PrintIngredientRecipe\n");
	printf("PrintIngredientRecipe(BBT,17)\n");
	PrintIngridientRecipe(BBT,17); printf("\n");

	return 0;
}
