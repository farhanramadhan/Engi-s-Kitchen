#include "graph.h"
#include "variable.h"
#include <stdio.h>
#include <stdlib.h>
#include "point.h"
Graph G;
infotype_graph Y;
adrNode P;
POINT X;
int i,j,temp;
// Membuat Prototype Tubes, membuat sebuah graph dengan n simpul, dimana tiap simpul akan di hubungkan dengan node tetangganya
int main(){
	FirstGraph(G) = Nil;
	printf("Masukkan Jumlah Node");
	scanf("%d",&i);
	if (i<=0){
		printf("Masukkan Jumlah Node");
		scanf("%d",&i);
	}
	temp = i;
	while (i>0){
		scanf("%d",&Id(Y));
		InsertNode(&G, Y, &P);
		CurrentGraph(G) = P;
		i--;
	}
	for ( i=1; i<=temp; i++){
		j = i % temp + 1;
		printf("Masukan Koordinat Perpindahaan dari %d ke %d :",i,j);
		scanf("%d %d", &Absis(X), &Ordinat(X));
		InsertEdge(&G,i,j,X);
	}
	printf("Where You are?");
	scanf("%d",&i);
	printf("Where are you going?");
	scanf("%d",&j);
	printf("You have to go to this coordinate : ");
	TulisPOINT(Door(SearchEdge(G,i,j)));
	system("pause");
}
