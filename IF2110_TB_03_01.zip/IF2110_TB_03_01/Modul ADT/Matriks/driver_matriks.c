#include <stdio.h>
#include "matriks.h"
#include "boolean.h"

/* Program Utama */
int main(){
  /* kamus */
  MATRIKS M1, M2;
  int Kolom, Baris; 
  /* algoritma */
  scanf("%d",&Baris); /* membaca jumlah baris */
  scanf("%d",&Kolom); /* membaca jumlah kolom */

  MakeMATRIKS(Baris,Kolom,&M1); /* Membentuk Matriks kosong M1 berukuran Baris x Kolom */
  
  /* Membentuk Matriks M2 BarisxKolom dengan Elemen sesuai masukan */
  BacaMATRIKS(&M2,Baris,Kolom);
  
  CopyMATRIKS(M2,&M1); /* menyalin Matriks M2 ke M1 */

  TulisMATRIKS(M1); /* mencetak Matriks M1 */
  printf("\n");

  printf("%d", NBElmtMAT(M1)); /* mencetak jumlah elemen Matriks M1 */
  return 0;  
}