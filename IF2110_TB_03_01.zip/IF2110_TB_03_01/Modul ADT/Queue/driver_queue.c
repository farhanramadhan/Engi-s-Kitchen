#include "queue.h"
#include "variable.h"
#include <stdio.h>
#include <stdlib.h>

/* DRIVER QUEUE */

int main(){

    //Kamus Lokal
    Queue Q;


    //Algoritma
    /* Membuat Queue Kosong dengan MaxEl 10 */
    CreateEmptyQueue(&Q,10);

    /* TestCase */
    if (IsEmptyQueue(Q)){
        printf("Queue Kosong\n");
    }
    else{
        printf("Tidak Kosong\n");
    }

    /* TestCase */
    if (IsFullQueue(Q)){
        printf("Full!!\n");
    }
    else{
        printf("Tidak Penuh\n");
    }

    /* TestCase */
    printf("%d",NBElmtQueue(Q));

    /* TestCase */
    printf("\n");
    PrintQueue(Q);

    return 0;
}
