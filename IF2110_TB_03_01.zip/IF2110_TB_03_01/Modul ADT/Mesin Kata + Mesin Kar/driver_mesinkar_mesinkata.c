/* Driver untuk ADT mesinkar */
/* YoungAwKarin K01 IF17 */

#include "mesinkata.h"
#include "mesinkarmod.h"
#include <stdio.h>

/* Program Utama */
int main(){
  /* kamus */

  /* algoritma */
  /* untuk mesinkar.h dan mesinkata.h */
  STARTKATA(); /* memulai membaca pitakar.txt */
  while (!EndKata){ /* EndKata bernilai false */
    ADVKATA(); 
    if (EndKata){ /* mencetak CKata saat Endkata true */
      for (int i = 1; i <= CKata.Length; i++)
        printf("%c",CKata.TabKata[i]); /* mencetak karakter Ckata satu satu */
    }
  } /* EndKata bernilai ture */

  return 0;
}