/* Nama file : driver_jam.c
   Tanggal : 26 November 2018
   NIM/Nama : 13517055/Ahmad Naufal Hakim */

#include <stdio.h>
#include "boolean.h"
#include "jam.h"

int main()
{
	/*** Kamus ***/
	JAM J1;
	JAM J2;
	long X;
	int N_Detik;
	
	/*** Algoritma ***/
	//BacaJAM
	printf("Masukkan nilai HH1, MM1, dan SS1:\n");
	BacaJAM(&J1);
	
	printf("Masukkan nilai HH2, MM2, dan SS2:\n");
	BacaJAM(&J2);
	
	//TulisJAM
	printf("Ini data untuk J1: ");
	TulisJAM(J1); printf("\n");
	
	printf("Ini data untuk J2: ");
	TulisJAM(J2); printf("\n\n");
	
	//JAMToDetik
	printf("Ini konversi J1 ke detik:\n");
	printf("%ld",JAMToDetik(J1)); printf("\n");
	
	printf("Ini konversi J2 ke detik:\n");
	printf("%ld",JAMToDetik(J2)); printf("\n");
	
	//DetikToJAM
	printf("Masukkan nilai N:\n");
	scanf("%ld",&X);
	printf("Ini konversi detik N (long) ke jam:\n");
	TulisJAM(DetikToJAM(X)); printf("\n");
	
	//JEQ
	if (JEQ(J1,J2))
		printf("Benar bahwa J1 dan J2 adalah sama\n");
	else
		printf("Salah bahwa J1 dan J2 adalah sama\n");
	
	//JNEQ
	if (JNEQ(J1,J2))
		printf("Benar bahwa J1 dan J2 tidaklah sama\n");
	else
		printf("Salah bahwa J1 dan J2 tidaklah sama\n");
	
	//JLT
	if (JLT(J1,J2))
		printf("Benar bahwa J1 lebih kecil dari J2\n");
	else
		printf("Salah bahwa J1 lebih kecil dari J2\n");
	
	//JGT
	if (JGT(J1,J2))
		printf("Benar bahwa J1 lebih besar dari J2\n");
	else
		printf("Salah bahwa J1 lebih besar dari J2\n");
	
	//NextDetik
	printf("Untuk J1, 1 detik setelah ");
	TulisJAM(J1);
	printf(" adalah ");
	TulisJAM(NextDetik(J1)); printf("\n");
	
	printf("Untuk J2, 1 detik setelah ");
	TulisJAM(J2);
	printf(" adalah ");
	TulisJAM(NextDetik(J2)); printf("\n");
	
	//PrevDetik
	printf("Untuk J1, 1 detik sebelum ");
	TulisJAM(J1);
	printf(" adalah ");
	TulisJAM(PrevDetik(J1)); printf("\n");
	
	printf("Untuk J2, 1 detik sebelum ");
	TulisJAM(J2);
	printf(" adalah ");
	TulisJAM(PrevDetik(J2)); printf("\n");
	
	//Inisialisasi N_Detik
	printf("Masukkan nilai NDetik:\n");
	scanf("%d",&N_Detik);
	
	//NextNDetik
	printf("Untuk J1, %d detik setelah ",N_Detik);
	TulisJAM(J1);
	printf(" adalah ");
	TulisJAM(NextNDetik(J1,N_Detik)); printf("\n");
	
	printf("Untuk J2, %d detik setelah ",N_Detik);
	TulisJAM(J2);
	printf(" adalah ");
	TulisJAM(NextNDetik(J2,N_Detik)); printf("\n");
	
	//PrevNDetik
	printf("Untuk J1, %d detik sebelum ",N_Detik);
	TulisJAM(J1);
	printf(" adalah ");
	TulisJAM(PrevNDetik(J1,N_Detik)); printf("\n");
	
	printf("Untuk J2, %d detik sebelum ",N_Detik);
	TulisJAM(J2);
	printf(" adalah ");
	TulisJAM(PrevNDetik(J2,N_Detik)); printf("\n");
	
	//Durasi
	printf("Durasi antara J1 dengan J2 dalam detik adalah:\n");
	printf("%ld",Durasi(J1,J2)); printf("\n");
	
	return 0;
}
