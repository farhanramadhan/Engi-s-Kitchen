#include "point.h"
#include "boolean.h"
#include <stdio.h>

void PrintBoolean(boolean Bool);

int main() {
    /* KAMUS */
    POINT P, P1, P2;

    /* ALGORITMA */
    /* Membuat point P dengan koordinat X = 3 dan Y = 5 */
    P = MakePOINT(3,5);
    TulisPOINT(P);

    /* Mengganti point P dengan input */
    BacaPOINT(&P);
    TulisPOINT(P);

    /* Boolean P */
    P1 = MakePOINT(0,0);
    P2 = MakePOINT(0,0);
    PrintBoolean(EQ(P1, P2));
    PrintBoolean(IsOrigin(P1));
    PrintBoolean(IsOnSbX(P2));
    PrintBoolean(IsOnSbY(P2));

    printf("Kuadran P : %d\n", Kuadran(P));

    return 0;
}

void PrintBoolean(boolean Bool) {
/* Prosedur untuk menampilkan boolean */
    if (Bool) {
        printf("True\n");
    } else {
        printf("False\n");
    }
}