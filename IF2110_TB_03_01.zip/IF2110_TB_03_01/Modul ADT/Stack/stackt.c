/* Nama : Gama Pradipta Wirawan
 * Nim : 13517049
 * Nama File : stackt.c*/

#include "stackt.h"
#include <stdio.h>
#include "variable.h"
void CreateEmptyStack (Stack *S)
/* I.S. sembarang; */
/* F.S. Membuat sebuah stack S yang kosong berkapasitas MaxEl */
/* jadi indeksnya antara 1.. MaxEl+1 karena 0 tidak dipakai */
/* Ciri stack kosong : TOP bernilai Nil */
{
	Top(*S)=Nill;
}

boolean IsEmptyStack (Stack S)
/* Mengirim true jika Stack kosong: lihat definisi di atas */
{
	return (Top(S)==Nill);
}
boolean IsFullStack (Stack S)
/* Mengirim true jika tabel penampung nilai elemen stack penuh */
{
	return (Top(S)==MaxEl);
}
/* ************ Menambahkan sebuah elemen ke Stack ************ */
void Push (Stack * S, infotype_stack X)
/* Menambahkan X sebagai elemen Stack S. */
/* I.S. S mungkin kosong, tabel penampung elemen stack TIDAK penuh */
/* F.S. X menjadi TOP yang baru,TOP bertambah 1 */
{
	Top(*S)++;
	InfoTop(*S)=X;
}
/* ************ Menghapus sebuah elemen Stack ************ */
void Pop (Stack * S, infotype_stack* X)
/* Menghapus X dari Stack S. */
/* I.S. S  tidak mungkin kosong */
/* F.S. X adalah nilai elemen TOP yang lama, TOP berkurang 1 */
{
	*X=InfoTop(*S);
	Top(*S)--;
}

void PrintStack( Stack S, char str[100]){
/* Menuliskan Isi Stack */
/* I.S. S mungkin kosong */
/* F.S. Menampilkan isi dari stack tersebut */
	Stack temp;
	infotype_stack X;
	if (IsEmptyStack(S))
		printf("Stack %s Kosong!!",str);
	else{
		temp = S;
		while (!IsEmptyStack(temp)){
			Pop(&temp,&X);
			printf("%d",X);
		}
	}
}
