#include "stackt.h"
#include <stdio.h>
#include "variable.h"
/* DRIVER STACKT */
int main(){

    //Kamus Lokal
    Stack S;
    char str[100];
    //Algoritma
    /* Membentuk Stack Kosong */
    CreateEmptyStack(&S);

    /* TestCase */
    if (IsEmptyStack(S)){
        printf("Kosong\n");
    }
    else{
        printf("Tidak Kosong\n");
    }

    /* TestCase */
    if (IsFullStack(S)){
        printf("Full\n");
    }
    else{
        printf("Gak Full\n");
    }

    /* TestCase */
    int X=5,Y;
    Push(&S,X);
    printf("Elemen Yang Di Push :\n");
    PrintStack(S,str);
    printf("\n");
    /* TestCase */
    Pop(&S,&Y);
    printf(" Elemen Yang Di Pop :%d",Y);
    printf("\n");
    PrintStack(S,str);

    return 0;
}
